# -*- coding: utf-8 -*-
"""
jarvis3.py — ジャービスPC v3.1（JarvisNEO）メインアプリ（単一ファイル）。

鳥さんの Windows パソコン（tora）で動く、無料・オフライン中心のAI執事。
v2（声/聞き耳/PC操作/目/動画の実証済みコード）と SarashinaChat
（性格カード/全カスタム設定/SQLite全記録/Web検索の実証済みコード）を土台に再利用。

v3.1 の核:
  - 性格（別枠1）: 言葉→Wikipedia調査→性格カード8項目。複数保存・切替・編集。
  - 自分コピー（別枠2）: 性格とは完全分離。鳥自身の特徴ファイルを入れる場所。
    parse_self_profile() で8項目に自動振り分けし、どの文も捨てない。
    v3.1: どんな書き方でも読める（見出し/キー：値/箇条書き/Q&A/会話ログ/
    Markdown表/CSV・TSV/日記/長文、Shift_JIS等の文字コード自動判定、
    複数ファイル・フォルダごと取り込み）。原文はチャンクで全文保存し、
    会話ごとに build_self_context() が必要な部分を取り出す。
  - 作る力: 計画→ファイル生成→自動検証→最大3回まで自動修正→要素照合レポート。
  - 黒いコンソール窓は絶対に出さない。全ての子プロセスは hidden 経由。
通信は基本 127.0.0.1 のみ。Web検索を使う時だけ外に出る（設定で切れる）。
"""
import json
import os
import queue
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, scrolledtext, ttk
except Exception:  # ヘッドレス環境（テスト）でも純粋ロジックは使えるように
    tk = None
    filedialog = messagebox = scrolledtext = ttk = None

_winsound = None
if sys.platform == "win32":
    try:
        import winsound as _winsound_mod
        _winsound = _winsound_mod
    except Exception:
        _winsound = None

_vosk = None
_sd = None
try:
    import vosk as _vosk_mod
    import sounddevice as _sd_mod
    _vosk = _vosk_mod
    _sd = _sd_mod
except Exception:
    _vosk = None
    _sd = None
VOICE_INPUT_AVAILABLE = _vosk is not None and _sd is not None

_imageio_ffmpeg = None
try:
    import imageio_ffmpeg as _iio_ffmpeg_mod
    _imageio_ffmpeg = _iio_ffmpeg_mod
except Exception:
    _imageio_ffmpeg = None

APP_NAME = "JarvisPC3"
MODEL_FILENAME_HINT = "sarashina2.2"

# ===========================================================================
# 純粋ロジック（GUIにも音にも触らない。単体テスト対象）
# ===========================================================================

_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)
_THINK_OPEN_RE = re.compile(r"<think>.*$", re.DOTALL | re.IGNORECASE)


def strip_think(text):
    """<think>...</think> を取り除く。閉じタグが無い場合も末尾まで除去。"""
    if not text:
        return ""
    text = _THINK_RE.sub("", text)
    text = _THINK_OPEN_RE.sub("", text)
    text = text.replace("</s>", "")
    return text.strip()


# ---------------------------------------------------------------------------
# 買い物ガード / 破壊的ガード（v2 継承）
# ---------------------------------------------------------------------------

SHOPPING_KEYWORDS_JA = ["購入", "注文", "支払", "決済", "買う", "カート", "チェックアウト", "レジ"]
SHOPPING_KEYWORDS_EN = ["buy", "pay", "checkout", "order"]


def needs_shopping_confirm(*texts):
    for t in texts:
        if not t:
            continue
        for k in SHOPPING_KEYWORDS_JA:
            if k in t:
                return True
        low = t.lower()
        for k in SHOPPING_KEYWORDS_EN:
            if k in low:
                return True
    return False


_DESTRUCTIVE_RES = [
    re.compile(r"\bshutdown\b", re.IGNORECASE),
    re.compile(r"\brestart-computer\b", re.IGNORECASE),
    re.compile(r"\bstop-computer\b", re.IGNORECASE),
    re.compile(r"\blogoff\b", re.IGNORECASE),
    re.compile(r"\bformat\s+[a-z]:", re.IGNORECASE),
    re.compile(r"\b(del|erase)\b[^|&;\n]*/s\b", re.IGNORECASE),
    re.compile(r"\b(rd|rmdir)\b[^|&;\n]*/s\b", re.IGNORECASE),
    re.compile(r"\bremove-item\b[^|&;\n]*-recurse", re.IGNORECASE),
    re.compile(r"\brm\s+-[a-z]*rf\b", re.IGNORECASE),
    re.compile(r"\brm\s+-[a-z]*fr\b", re.IGNORECASE),
]


def needs_destructive_confirm(*texts):
    for t in texts:
        if not t:
            continue
        for rx in _DESTRUCTIVE_RES:
            if rx.search(t):
                return True
    return False


# ---------------------------------------------------------------------------
# 行動行パーサ（v2 継承）
# ---------------------------------------------------------------------------

_ACTION_PREFIXES = [
    ("ファイル作成", "create_file"),
    ("ファイル編集", "edit_file"),
    ("名前をクリック", "click_name"),
    ("見てクリック", "see_click"),
    ("見て", "see"),
    ("ダブルクリック", "double_click"),
    ("右クリック", "right_click"),
    ("クリック", "click"),
    ("スクロール", "scroll"),
    ("ドラッグ", "drag"),
    ("おわり", "done"),
    ("開く", "open"),
    ("アプリ", "app"),
    ("コマンド", "command"),
    ("丸", "circle"),
    ("線", "line"),
    ("キー", "key"),
    ("入力", "type_text"),
    ("移動", "move"),
    ("前面", "front"),
    ("閉じる", "close_window"),
    ("最大化", "maximize"),
    ("最小化", "minimize"),
    ("明るさ", "brightness"),
    ("スクショ", "screenshot"),
    ("ページ", "page"),
    ("動画", "make_video"),
    ("待つ", "wait"),
]
ACTION_LINE_PREFIXES = tuple(p for p, _ in _ACTION_PREFIXES)
_LEADING_JUNK_RE = re.compile(r"^[\s\-・*＊>＞#\d\.、．)）]+")
_NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")


def _clamp_pct(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(100.0, f))


def _numbers(text, count):
    found = _NUM_RE.findall(text or "")
    vals = [_clamp_pct(x) for x in found[:count]]
    while len(vals) < count:
        vals.append(0.0)
    return vals


def _first_number(text, default=0.0):
    found = _NUM_RE.findall(text or "")
    if not found:
        return default
    try:
        return float(found[0])
    except ValueError:
        return default


def _split_action_line(line):
    s = _LEADING_JUNK_RE.sub("", line.strip())
    for prefix, kind in _ACTION_PREFIXES:
        if s.startswith(prefix):
            rest = s[len(prefix):].lstrip()
            if rest[:1] in (":", "："):
                rest = rest[1:]
            return kind, rest.strip()
    return None, s


def parse_action(text):
    """モデルの返事テキストを行動 dict に解釈する（v2 と同じ語彙）。"""
    cleaned = strip_think(text or "")
    if not cleaned:
        return {"type": "text", "text": ""}
    lines = cleaned.splitlines()
    for i, line in enumerate(lines):
        kind, rest = _split_action_line(line)
        if kind is None:
            continue
        body = "\n".join(lines[i + 1:]).strip("\n")
        if kind in ("create_file", "edit_file"):
            name = rest.split()[0] if rest.split() else "無題.txt"
            return {"type": kind, "name": name, "body": body}
        if kind == "open":
            return {"type": "open", "name": rest}
        if kind == "app":
            return {"type": "app", "target": rest}
        if kind == "command":
            cmd = rest if rest else body
            return {"type": "command", "cmd": cmd.strip()}
        if kind == "circle":
            x, y = _numbers(rest, 2)
            return {"type": "circle", "x": x, "y": y}
        if kind == "line":
            x1, y1, x2, y2 = _numbers(rest, 4)
            return {"type": "line", "x1": x1, "y1": y1, "x2": x2, "y2": y2}
        if kind in ("click", "double_click", "right_click"):
            x, y = _numbers(rest, 2)
            return {"type": kind, "x": x, "y": y}
        if kind == "key":
            return {"type": "key", "spec": rest.replace(" ", "").lower()}
        if kind == "type_text":
            txt = rest if rest else body
            return {"type": "type_text", "text": txt.strip()}
        if kind == "scroll":
            amount = int(_first_number(rest, 0))
            return {"type": "scroll", "amount": max(-1200, min(1200, amount))}
        if kind == "wait":
            sec = _first_number(rest, 0.0)
            return {"type": "wait", "seconds": max(0.0, min(10.0, sec))}
        if kind == "move":
            x, y = _numbers(rest, 2)
            return {"type": "move", "x": x, "y": y}
        if kind == "drag":
            x1, y1, x2, y2 = _numbers(rest, 4)
            return {"type": "drag", "x1": x1, "y1": y1, "x2": x2, "y2": y2}
        if kind in ("front", "close_window", "maximize", "minimize"):
            return {"type": kind, "title": rest}
        if kind == "click_name":
            return {"type": "click_name", "name": rest}
        if kind == "brightness":
            level = int(_first_number(rest, 50))
            return {"type": "brightness", "level": max(0, min(100, level))}
        if kind == "screenshot":
            return {"type": "screenshot", "name": rest if rest else "スクショ.png"}
        if kind == "see":
            return {"type": "see", "question": rest}
        if kind == "see_click":
            return {"type": "see_click", "name": rest}
        if kind == "page":
            return {"type": "page", "question": rest}
        if kind == "make_video":
            return {"type": "make_video", "theme": rest}
        if kind == "done":
            summary = rest if rest else body
            return {"type": "done", "summary": summary.strip()}
    return {"type": "text", "text": cleaned}


_NAMED_VK = {
    "enter": 0x0D, "return": 0x0D, "esc": 0x1B, "escape": 0x1B, "tab": 0x09,
    "win": 0x5B, "windows": 0x5B, "up": 0x26, "down": 0x28, "left": 0x25,
    "right": 0x27, "backspace": 0x08, "bs": 0x08, "delete": 0x2E, "del": 0x2E,
    "space": 0x20, "ctrl": 0x11, "control": 0x11, "alt": 0x12, "shift": 0x10,
    "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22, "insert": 0x2D,
    "volume_up": 0xAF, "volume_down": 0xAE, "mute": 0xAD,
    "next": 0xB0, "prev": 0xB1, "play_pause": 0xB3, "play": 0xB3, "pause": 0xB3,
}
for _i in range(1, 13):
    _NAMED_VK["f%d" % _i] = 0x70 + (_i - 1)


def key_spec_to_vk(spec):
    if not spec:
        return None
    parts = [p for p in re.split(r"[+＋]", str(spec).strip().lower()) if p != ""]
    if not parts:
        return None
    vks = []
    for p in parts:
        if p in _NAMED_VK:
            vks.append(_NAMED_VK[p])
        elif len(p) == 1 and ("a" <= p <= "z" or "0" <= p <= "9"):
            vks.append(ord(p.upper()))
        else:
            return None
    return vks


def build_sarashina_prompt(system, turns):
    """Sarashina形式プロンプト（v2/SarashinaChat 継承）。"""
    parts = []
    if system:
        parts.append("<|system|>" + system.strip() + "</s>")
    for role, text in turns:
        tag = "<|user|>" if role == "user" else "<|assistant|>"
        if role == "system":
            tag = "<|system|>"
        parts.append(tag + (text or "").strip() + "</s>")
    parts.append("<|assistant|>")
    return "".join(parts)


def build_openai_messages(system, turns):
    """OpenAI互換API用メッセージ（llama-server の /v1/chat/completions 向け）。"""
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    for role, text in turns:
        r = role if role in ("user", "assistant", "system") else "user"
        msgs.append({"role": r, "content": text or ""})
    return msgs


def sanitize_relpath(name):
    if not name:
        return "無題.txt"
    n = str(name).strip().strip('"').strip("'")
    n = re.sub(r"^[a-zA-Z]:", "", n)
    n = n.replace("\\", "/")
    parts = []
    for p in n.split("/"):
        p = p.strip()
        if p in ("", ".", ".."):
            continue
        parts.append(p)
    if not parts:
        return "無題.txt"
    return "/".join(parts)


def safe_join(base, name):
    rel = sanitize_relpath(name)
    base_abs = os.path.abspath(base)
    path = os.path.abspath(os.path.join(base_abs, *rel.split("/")))
    if path != base_abs and not path.startswith(base_abs + os.sep):
        return None
    return path


# ---------------------------------------------------------------------------
# 読み上げ掃除（v2 継承）
# ---------------------------------------------------------------------------

_SPEECH_MAX_SENTENCES = 3
_SPEECH_MAX_CHARS = 180
_URL_RE = re.compile(r"https?://\S+|www\.\S+")
_LINK_RE = re.compile(r"\[([^\]]*)\]\([^)]*\)")
_FENCE_RE = re.compile(r"```.*?```", re.DOTALL)
_FENCE_OPEN_RE = re.compile(r"```.*$", re.DOTALL)
_INLINE_CODE_RE = re.compile(r"`[^`\n]*`")
_WIN_PATH_RE = re.compile(r"[a-zA-Z]:[\\/][^\s、。，]*")
_UNIX_PATH_RE = re.compile(r"(?<![\w])/(?:[\w.\-]+/)+[\w.\-]*")
_FILE_TOKEN_RE = re.compile(r"[\w\-.]+\.(?:gguf|txt|md|py|json|exe|bat|ps1|zip|png|jpg|jpeg|gif|csv|log|html?|xml|ya?ml|ini|dll)\b", re.IGNORECASE)
_SYMBOL_RE = re.compile(
    "[\U0001F000-\U0001FAFF\U00002600-\U000027BF\U00002B00-\U00002BFF"
    "\U0001F1E6-\U0001F1FF※◎○●◯■□▣▤▥▲△▼▽◆◇♦♠♣♥♦→←↑↓⇒⇔≪≫«»†‡]")
_MD_CHARS_RE = re.compile(r"[#*_>~|]")


def _is_action_line(line):
    s = _LEADING_JUNK_RE.sub("", line.strip())
    return any(s.startswith(p) for p in ACTION_LINE_PREFIXES)


def sanitize_for_speech(text):
    t = strip_think(text or "")
    if not t:
        return ""
    t = _FENCE_RE.sub(" ", t)
    t = _FENCE_OPEN_RE.sub(" ", t)
    kept = []
    for line in t.splitlines():
        s = line.strip()
        if not s:
            continue
        kind, rest = _split_action_line(s)
        if kind == "done":
            if rest:
                kept.append(rest)
            continue
        if kind is not None or _is_action_line(s):
            continue
        kept.append(s)
    t = "\n".join(kept)
    t = _LINK_RE.sub(r"\1", t)
    t = _URL_RE.sub(" ", t)
    t = _WIN_PATH_RE.sub(" ", t)
    t = _UNIX_PATH_RE.sub(" ", t)
    t = _FILE_TOKEN_RE.sub(" ", t)
    t = _INLINE_CODE_RE.sub(" ", t)
    t = _MD_CHARS_RE.sub("", t)
    t = _SYMBOL_RE.sub("", t)
    t = re.sub(r"\s+", " ", t).strip()
    if not t:
        return ""
    sentences = [s for s in re.split(r"(?<=[。！？])", t) if s.strip()]
    out = ""
    for s in sentences:
        if out and (len(out) + len(s) > _SPEECH_MAX_CHARS or
                    out.count("。") + out.count("！") + out.count("？") >= _SPEECH_MAX_SENTENCES):
            break
        if not out and len(s) > _SPEECH_MAX_CHARS:
            out = s[:_SPEECH_MAX_CHARS]
            break
        out += s
        if len(out) >= _SPEECH_MAX_CHARS:
            break
    return out.strip()


# ---------------------------------------------------------------------------
# 聞き耳の状態機械（v2 継承）
# ---------------------------------------------------------------------------

WAKE_PREFIXES = ("ジャービス", "じゃーびす", "じゃあびす")
QUIET_PHRASES = ("聞くのをやめて", "聞き耳を止めて", "静かにして", "ミュート")
RESUME_PHRASES = ("聞き耳を始めて", "聞いてる", "聞いて")
TASK_STOP_PHRASES = ("止めて", "ストップ", "とめて")
_COMPACT_DROP_RE = re.compile(r"[\s、,。．.！!？?・…]+")
_WAKE_STRIP_RE = re.compile(r"^\s*(ジャービス|じゃーびす|じゃあびす)[、,。\s]*")


def _compact(s):
    return _COMPACT_DROP_RE.sub("", s or "")


def _strip_wake_prefix(raw):
    return _WAKE_STRIP_RE.sub("", raw or "").strip()


def _starts_with_any(compact_text, phrases):
    return any(compact_text == p or compact_text.startswith(p) for p in phrases)


class ListenStateMachine:
    LISTENING = "LISTENING"
    QUIET = "QUIET"
    FULL_OFF = "FULL_OFF"
    SPEAKING_MUTED = "SPEAKING_MUTED"
    ECHO_COOLDOWN_SEC = 1.0

    def __init__(self):
        self.mode = self.LISTENING
        self._speaking = False
        self._cooldown_until = 0.0

    def state(self, now=None):
        if self.mode == self.LISTENING:
            if self._speaking or self._in_cooldown(now):
                return self.SPEAKING_MUTED
        return self.mode

    def _in_cooldown(self, now):
        if now is None:
            now = time.monotonic()
        return now < self._cooldown_until

    def set_speaking(self, speaking, now=None):
        if now is None:
            now = time.monotonic()
        if speaking:
            self._speaking = True
        else:
            self._speaking = False
            self._cooldown_until = now + self.ECHO_COOLDOWN_SEC

    def full_stop(self):
        self.mode = self.FULL_OFF

    def full_start(self):
        self.mode = self.LISTENING

    def go_quiet(self):
        if self.mode == self.LISTENING:
            self.mode = self.QUIET

    def feed(self, text, now=None):
        if now is None:
            now = time.monotonic()
        raw = (text or "").strip()
        compact = _compact(raw)
        if self.mode == self.FULL_OFF:
            return {"action": "ignore", "reason": "full_off"}
        if not compact:
            return {"action": "ignore", "reason": "empty"}
        if self.mode == self.QUIET:
            body = _compact(_strip_wake_prefix(raw))
            if _starts_with_any(body, RESUME_PHRASES):
                self.mode = self.LISTENING
                return {"action": "resume"}
            return {"action": "ignore", "reason": "quiet"}
        if self._speaking or now < self._cooldown_until:
            return {"action": "ignore", "reason": "speaking"}
        body_raw = _strip_wake_prefix(raw)
        body = _compact(body_raw)
        if not body:
            return {"action": "ignore", "reason": "empty"}
        if _starts_with_any(body, QUIET_PHRASES):
            self.mode = self.QUIET
            return {"action": "quiet"}
        if body in TASK_STOP_PHRASES:
            return {"action": "stop_task"}
        if len(body) < 2:
            return {"action": "ignore", "reason": "too_short"}
        return {"action": "message", "text": body_raw.strip()}


# ---------------------------------------------------------------------------
# 失敗ブレーキ（部品ごとに連続例外を数え、閾値でその部品だけ止める）
# ---------------------------------------------------------------------------

class FailureBrake:
    def __init__(self, threshold=5):
        self.threshold = threshold
        self._counts = {}
        self._tripped = set()
        self._lock = threading.Lock()

    def record_failure(self, part):
        with self._lock:
            self._counts[part] = self._counts.get(part, 0) + 1
            if self._counts[part] >= self.threshold:
                self._tripped.add(part)
            return part in self._tripped

    def record_success(self, part):
        with self._lock:
            self._counts[part] = 0
            self._tripped.discard(part)

    def is_tripped(self, part):
        with self._lock:
            return part in self._tripped

    def reset(self, part=None):
        with self._lock:
            if part is None:
                self._counts.clear()
                self._tripped.clear()
            else:
                self._counts.pop(part, None)
                self._tripped.discard(part)


# ===========================================================================
# パスと設定
# ===========================================================================

FROZEN = bool(getattr(sys, "frozen", False))
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def res_path(rel):
    base = getattr(sys, "_MEIPASS", None) or SCRIPT_DIR
    return os.path.join(base, rel)


def _data_dir():
    """exe では %LOCALAPPDATA%\\JarvisPC3、通常実行ではスクリプトの隣。"""
    if FROZEN:
        root = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(root, "JarvisPC3")
    return SCRIPT_DIR


DATA_DIR = _data_dir()
CONFIG_PATH = os.path.join(DATA_DIR, "config.json")
DATA_SUBDIR = os.path.join(DATA_DIR, "data")
PERSONA_DIR = os.path.join(DATA_SUBDIR, "personalities")
SELF_PROFILE_PATH = os.path.join(DATA_SUBDIR, "self_profile.json")
SELF_PROFILE_DIR = os.path.join(DATA_SUBDIR, "self_profile")
SELF_CHUNKS_PATH = os.path.join(DATA_SUBDIR, "self_profile_chunks.jsonl")
FACTS_PATH = os.path.join(DATA_SUBDIR, "facts.txt")
MEMORY_DB_PATH = os.path.join(DATA_SUBDIR, "memory.db")
WORKSPACE_DIR = os.path.join(DATA_DIR, "workspace")
MODELS_DIR = os.path.join(DATA_DIR, "models")
SHOTS_DIR = os.path.join(DATA_DIR, "shots")
LOG_DIR = os.path.join(DATA_DIR, "logs")
LOG_PATH = os.path.join(LOG_DIR, "jarvis3.log")
LLAMA_DIR = os.path.join(DATA_DIR, "llama") if FROZEN else os.path.join(SCRIPT_DIR, "llama")
LLAMA_EXE = os.path.join(LLAMA_DIR, "llama-server.exe")
VOSK_MODEL_NAME = "vosk-model-small-ja-0.22"
VOSK_MODEL_DIR = (os.path.join(DATA_DIR, VOSK_MODEL_NAME) if FROZEN
                  else os.path.join(SCRIPT_DIR, VOSK_MODEL_NAME))
SERVER_BASE = "http://127.0.0.1:8080"

DEFAULT_CONFIG = {
    "model_path": "",
    "mmproj_path": "",
    "llama_server_path": "",
    "port": 8080,
    "api_mode": "sarashina",
    "context_size": 8192,
    "threads": 4,
    "temperature": 0.7,
    "top_p": 0.95,
    "top_k": 40,
    "min_p": 0.05,
    "repeat_penalty": 1.1,
    "repeat_last_n": 64,
    "seed": -1,
    "n_predict": 1024,
    "custom_stop": "",
    "speaker_id": 11,
    "voice_on": True,
    "listen_on": True,
    "agent_on": False,
    "autostart": False,
    "video_tate": True,
    "persona_strength": "max",
    "persona_id": "",
    "copy_mode": False,
    "recent_turns": 40,
    "retrieve_count": 6,
    "facts_enabled": True,
    "web_mode": "auto",
    "web_max_results": 5,
    "web_fetch_pages": 2,
    "web_snippet_chars": 1200,
    "web_keywords": "今日,最新,ニュース,天気,予報,価格,値段,調べて,検索,速報,結果,誰,いつ,どこ,いくら,何時,何日,おすすめ,比較,違い,意味,とは",
    "auto_web_research": True,
    "profile_gen_tokens": 1400,
    "profile_gen_temperature": 0.3,
    "maker_max_retries": 3,
    "system_extra": "",
    "user_name": "鳥",
    "font_size": 11,
}

SETTINGS_SCHEMA = [
    ("model_path", "モデルGGUFの場所（空=自動検出）", "str"),
    ("mmproj_path", "目のファイル mmproj GGUF（任意）", "str"),
    ("llama_server_path", "llama-serverの場所（空=llamaフォルダ）", "str"),
    ("port", "llama-server ポート", "int"),
    ("api_mode", "API方式（sarashina/openai）", "str"),
    ("context_size", "文脈の長さ", "int"),
    ("threads", "スレッド数", "int"),
    ("temperature", "temperature（自由さ）", "float"),
    ("top_p", "top_p", "float"),
    ("top_k", "top_k", "int"),
    ("min_p", "min_p", "float"),
    ("repeat_penalty", "repeat_penalty", "float"),
    ("repeat_last_n", "repeat_last_n", "int"),
    ("seed", "seed（-1=ランダム）", "int"),
    ("n_predict", "生成の上限トークン", "int"),
    ("custom_stop", "追加の停止文字列（カンマ区切り）", "str"),
    ("speaker_id", "VOICEVOX 話者ID", "int"),
    ("voice_on", "読み上げを使う", "bool"),
    ("listen_on", "ずっと聞き耳を使う", "bool"),
    ("agent_on", "PC操作（エージェント）を使う", "bool"),
    ("autostart", "Windows起動時に出す", "bool"),
    ("video_tate", "説明動画は縦長", "bool"),
    ("persona_strength", "性格の適用の強さ（normal/strong/max）", "str"),
    ("copy_mode", "自分コピーモード", "bool"),
    ("recent_turns", "直近をそのまま入れる往復数", "int"),
    ("retrieve_count", "過去から思い出す件数", "int"),
    ("facts_enabled", "ずっと覚えるメモを使う", "bool"),
    ("web_mode", "会話中Web検索（auto/always/off）", "str"),
    ("web_max_results", "Web検索の結果件数", "int"),
    ("web_fetch_pages", "本文まで読むページ数", "int"),
    ("web_snippet_chars", "1ページから読む最大文字数", "int"),
    ("web_keywords", "自動検索のきっかけ言葉（カンマ区切り）", "str"),
    ("auto_web_research", "性格作成時に自動で調べる", "bool"),
    ("profile_gen_tokens", "性格カード生成の上限トークン", "int"),
    ("profile_gen_temperature", "性格カード生成のtemperature", "float"),
    ("maker_max_retries", "作る力の自動修正の上限回数", "int"),
    ("system_extra", "全性格共通の追加指示", "str"),
    ("user_name", "あなたの表示名", "str"),
    ("font_size", "文字の大きさ", "int"),
]


def ensure_data_dirs():
    for d in (DATA_DIR, DATA_SUBDIR, PERSONA_DIR, SELF_PROFILE_DIR,
              WORKSPACE_DIR, MODELS_DIR, SHOTS_DIR, LOG_DIR):
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            pass


def prepare_bundled_resources():
    if not FROZEN:
        return
    ensure_data_dirs()
    for name, dest in (("llama", LLAMA_DIR), (VOSK_MODEL_NAME, VOSK_MODEL_DIR)):
        try:
            src = res_path(name)
            if os.path.isdir(src) and not os.path.isdir(dest):
                shutil.copytree(src, dest)
        except Exception:
            pass


def load_config(path=None):
    cfg = dict(DEFAULT_CONFIG)
    try:
        with open(path or CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            cfg.update(data)
    except (OSError, ValueError):
        pass
    try:
        cfg["speaker_id"] = int(cfg.get("speaker_id", 11))
    except (TypeError, ValueError):
        cfg["speaker_id"] = 11
    for k in ("voice_on", "listen_on", "agent_on", "autostart", "video_tate",
              "facts_enabled", "auto_web_research", "copy_mode"):
        cfg[k] = bool(cfg.get(k, DEFAULT_CONFIG[k]))
    return cfg


def save_config(path, cfg):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        return True
    except OSError:
        return False


def effective_config(cfg, persona=None):
    merged = dict(cfg)
    if persona:
        for k, v in (persona.get("overrides") or {}).items():
            if v is not None and v != "":
                merged[k] = v
    return merged


def detect_model(cfg):
    p = cfg.get("model_path") or ""
    if p and os.path.isfile(p):
        return p
    if os.path.isdir(MODELS_DIR):
        ggufs = sorted(f for f in os.listdir(MODELS_DIR) if f.lower().endswith(".gguf"))
        for f in ggufs:
            if MODEL_FILENAME_HINT in f.lower():
                return os.path.join(MODELS_DIR, f)
        if ggufs:
            return os.path.join(MODELS_DIR, ggufs[0])
    return ""


def llama_server_exe(cfg):
    p = cfg.get("llama_server_path") or ""
    if p and os.path.isfile(p):
        return p
    name = "llama-server.exe" if os.name == "nt" else "llama-server"
    return os.path.join(LLAMA_DIR, name)


_log_lock = threading.Lock()


def log_line(msg):
    try:
        ensure_data_dirs()
        line = "[%s] %s\n" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
        with _log_lock:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(line)
    except Exception:
        pass


CREATE_NO_WINDOW = 0x08000000


def _hidden_startupinfo():
    if sys.platform != "win32":
        return None
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0
    return si


def hidden_popen(args, hide_window=True, **kw):
    if sys.platform == "win32":
        kw.setdefault("creationflags", CREATE_NO_WINDOW)
        if hide_window:
            kw.setdefault("startupinfo", _hidden_startupinfo())
    return subprocess.Popen(args, **kw)


def run_hidden(args, hide_window=True, **kw):
    if sys.platform == "win32":
        kw.setdefault("creationflags", CREATE_NO_WINDOW)
        if hide_window:
            kw.setdefault("startupinfo", _hidden_startupinfo())
    return subprocess.run(args, **kw)


def _decode(b):
    if not b:
        return ""
    for enc in ("utf-8", "cp932"):
        try:
            return b.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return b.decode("utf-8", "replace")


def open_path(path):
    if sys.platform == "win32":
        os.startfile(path)  # noqa: S606
    else:
        hidden_popen(["xdg-open", path], hide_window=False)


# ===========================================================================
# 性格（別枠1）— SarashinaChat 方式
# ===========================================================================

PROFILE_FIELDS = [
    ("identity", "正体・設定"),
    ("traits", "性格の特徴"),
    ("speech", "話し方・口調・一人称・語尾・口癖"),
    ("likes_dislikes", "好きなもの・嫌いなもの"),
    ("knowledge", "詳しい分野・世界観"),
    ("rules", "振る舞いの決まり（こう話す・これはしない）"),
    ("greeting", "最初の挨拶の例"),
    ("examples", "セリフの例"),
]


def empty_profile():
    return {k: "" for k, _ in PROFILE_FIELDS}


def build_persona_section(persona):
    """性格だけのセクション（自分コピーはここには入れない）。"""
    if not persona:
        return ""
    prof = persona.get("profile") or {}
    name = persona.get("display_name") or persona.get("input_word") or "アシスタント"
    lines = []
    lines.append("あなたは「%s」です。以下の性格設定を守って、その人物・キャラクター本人として話してください。" % name)
    lines.append("AIであることや設定の説明はせず、常にその性格のまま自然に会話してください。")
    iw = (persona.get("input_word") or "").strip()
    if iw:
        lines.append("【元になった言葉】%s" % iw)
    memo = (persona.get("memo") or "").strip()
    if memo:
        lines.append("【ユーザーが足した希望】%s" % memo)
    label = dict(PROFILE_FIELDS)
    for key, _ in PROFILE_FIELDS:
        v = (prof.get(key) or "").strip()
        if v:
            lines.append("【%s】%s" % (label[key], v))
    web = (persona.get("web_summary") or "").strip()
    if web:
        lines.append("【調査メモ】%s" % web[:1500])
    custom = (persona.get("extra_prompt") or "").strip()
    if custom:
        lines.append("【追加の指示】%s" % custom)
    return "\n".join(lines)


def build_system_prompt(persona, self_profile=None, copy_mode=False, cfg=None):
    return build_full_system_prompt(persona, self_profile, copy_mode, cfg)


PROFILE_GEN_INSTRUCTION = """次の「言葉」について、あなたが知っていることを全部使って、その人物・キャラクター・性格を再現するための性格カードを作ってください。
出力は必ず次のJSONだけにしてください。説明文やコードブロック記号は書かないでください。
{"identity":"正体・設定を具体的に","traits":"性格の特徴を具体的に","speech":"話し方・口調・一人称・相手の呼び方・語尾・口癖を具体的に","likes_dislikes":"好きなもの・嫌いなもの","knowledge":"詳しい分野・いる世界の知識","rules":"会話で守る振る舞いの決まり","greeting":"その性格らしい最初の挨拶を1文","examples":"その性格らしいセリフ例を3つ、改行で区切って"}
分からない部分は、その言葉から一番自然に想像できる形で補ってください。"""


def parse_profile_json(text):
    """性格カードJSONのパース。壊れていれば項目ごとに拾って救済する。"""
    if not text:
        return None
    t = text.strip()
    t = re.sub(r"^```(json)?", "", t).strip()
    t = re.sub(r"```$", "", t).strip()
    start, end = t.find("{"), t.rfind("}")
    if start < 0:
        return None
    if end <= start:
        end = len(t) - 1  # 閉じ括弧が無い壊れたJSONでも項目ごとに救済を試す
    try:
        data = json.loads(t[start:end + 1])
    except Exception:
        data = {}
        for k in empty_profile():
            m = re.search(r'"%s"\s*:\s*"((?:[^"\\]|\\.)*)"' % k, t[start:end + 1])
            if m:
                try:
                    data[k] = json.loads('"%s"' % m.group(1))
                except Exception:
                    data[k] = m.group(1)
        if not any(str(v or "").strip() for v in data.values()):
            return None
    prof = empty_profile()
    for k in prof:
        v = data.get(k)
        if isinstance(v, list):
            v = "\n".join(str(x) for x in v)
        prof[k] = str(v or "").strip()
    if not any(prof.values()):
        return None
    return prof


def fallback_profile(input_word, memo, web_summary):
    prof = empty_profile()
    prof["identity"] = input_word
    prof["traits"] = memo or "「%s」らしい性格で話す。" % input_word
    if web_summary:
        prof["knowledge"] = web_summary[:800]
    prof["speech"] = "「%s」らしい口調で、自然な日本語で話す。" % input_word
    prof["rules"] = "設定を守って会話する。会話の内容はよく覚えて、以前の話と繋げて話す。"
    return prof


class PersonalityStore:
    def __init__(self, base_dir=None):
        self.base = base_dir or PERSONA_DIR
        os.makedirs(self.base, exist_ok=True)

    def _path(self, pid):
        return os.path.join(self.base, pid + ".json")

    def list_all(self):
        out = []
        for f in sorted(os.listdir(self.base)):
            if f.endswith(".json"):
                try:
                    with open(os.path.join(self.base, f), encoding="utf-8") as fh:
                        out.append(json.load(fh))
                except Exception:
                    pass
        out.sort(key=lambda p: p.get("created_at", ""))
        return out

    def get(self, pid):
        if not pid:
            return None
        p = self._path(pid)
        if os.path.isfile(p):
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        return None

    def save(self, persona):
        persona["updated_at"] = datetime.now().isoformat(timespec="seconds")
        with open(self._path(persona["id"]), "w", encoding="utf-8") as f:
            json.dump(persona, f, ensure_ascii=False, indent=2)
        return persona

    def create(self, input_word, memo="", display_name=""):
        pid = uuid.uuid4().hex[:12]
        persona = {
            "id": pid,
            "input_word": (input_word or "").strip(),
            "display_name": (display_name or input_word or "").strip(),
            "memo": (memo or "").strip(),
            "profile": empty_profile(),
            "web_summary": "",
            "web_source": "",
            "extra_prompt": "",
            "overrides": {},
            "profile_source": "none",
            "system_prompt": "",
            "created_at": datetime.now().isoformat(timespec="microseconds"),
            "updated_at": datetime.now().isoformat(timespec="seconds"),
        }
        persona["system_prompt"] = build_persona_section(persona)
        return self.save(persona)

    def delete(self, pid):
        p = self._path(pid)
        if os.path.isfile(p):
            os.remove(p)


def web_research(term, timeout=12):
    term = (term or "").strip()
    if not term:
        return None
    for lang in ("ja", "en"):
        try:
            q = urllib.parse.urlencode({
                "action": "query", "prop": "extracts", "explaintext": "1",
                "format": "json", "titles": term, "redirects": "1",
            })
            url = "https://%s.wikipedia.org/w/api.php?%s" % (lang, q)
            req = urllib.request.Request(url, headers={"User-Agent": "JarvisPC3/1.0 (personality research)"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode("utf-8", "replace"))
            pages = (data.get("query") or {}).get("pages") or {}
            for page in pages.values():
                extract = (page.get("extract") or "").strip()
                if extract:
                    return {
                        "title": page.get("title") or term,
                        "extract": extract[:3000],
                        "url": "https://%s.wikipedia.org/wiki/%s" % (
                            lang, urllib.parse.quote((page.get("title") or term).replace(" ", "_"))),
                    }
        except Exception:
            continue
    return None


def research_and_build_personality(store, persona, client, cfg, on_step):
    """Wikipedia調査→性格カード生成（JSON救済パース+最大2回）。SarashinaChat方式。"""
    word = persona.get("input_word", "")
    if cfg.get("auto_web_research", True):
        on_step("「%s」を調べています…（Wikipedia）" % word)
        hit = web_research(word)
        if hit:
            persona["web_summary"] = hit["extract"]
            persona["web_source"] = hit["url"]
            on_step("調べられました: %s" % hit["title"])
        else:
            on_step("Webでは見つからなかったので、モデルの知識で展開します")
    used_llm = False
    if client is not None:
        on_step("性格カードを作っています…")
        material = PROFILE_GEN_INSTRUCTION + "\n\n【言葉】" + word
        if persona.get("memo"):
            material += "\n【ユーザーの希望】" + persona["memo"]
        if persona.get("web_summary"):
            material += "\n【調べた内容】" + persona["web_summary"][:2000]
        try:
            prof = None
            for attempt in range(2):
                mat = material if attempt == 0 else material + "\n【注意】必ず有効なJSONだけを出力してください。文章や説明は禁止です。"
                raw = client.generate_once(
                    "あなたは性格設定を作る専門家です。指定されたJSON形式だけで答えてください。",
                    mat,
                    n_predict=int(cfg.get("profile_gen_tokens", 1400)),
                    temperature=0.3 if attempt == 0 else 0.15)
                prof = parse_profile_json(raw)
                if prof:
                    break
            if prof:
                persona["profile"] = prof
                persona["profile_source"] = "llama"
                used_llm = True
                on_step("性格カードができました")
            else:
                on_step("性格カードの読み取りに失敗したので、仮カードを使います")
                persona["profile"] = fallback_profile(word, persona.get("memo", ""), persona.get("web_summary", ""))
                persona["profile_source"] = "fallback"
        except Exception as e:
            on_step("モデルでの生成に失敗しました（%s）。仮カードを使います" % e)
            persona["profile"] = fallback_profile(word, persona.get("memo", ""), persona.get("web_summary", ""))
            persona["profile_source"] = "fallback"
    else:
        persona["profile"] = fallback_profile(word, persona.get("memo", ""), persona.get("web_summary", ""))
        persona["profile_source"] = "fallback"
        on_step("モデル未起動のため仮カードです")
    persona["system_prompt"] = build_persona_section(persona)
    store.save(persona)
    return persona, used_llm


# ===========================================================================
# 自分コピー（別枠2・性格とは完全分離）
# ===========================================================================

SELF_FIELDS = [
    ("basic", "基本"),
    ("speech", "話し方・口癖"),
    ("likes_dislikes", "好き嫌い"),
    ("thinking", "考え方・決め方"),
    ("habits", "習慣"),
    ("skills", "得意・苦手"),
    ("memories", "思い出・その他"),
    ("values", "大事なこと"),
]
SELF_FIELD_LABELS = dict(SELF_FIELDS)

_SELF_HEADING_ALIASES = {
    "基本": "basic", "基本情報": "basic", "プロフィール": "basic", "自己紹介": "basic",
    "話し方": "speech", "話し方・口癖": "speech", "口癖": "speech", "言葉遣い": "speech",
    "好き嫌い": "likes_dislikes", "好きなもの": "likes_dislikes", "嫌いなもの": "likes_dislikes",
    "好き": "likes_dislikes", "嫌い": "likes_dislikes",
    "考え方": "thinking", "考え方・決め方": "thinking", "決め方": "thinking", "性格": "thinking",
    "習慣": "habits", "いつものこと": "habits", "日常": "habits",
    "得意・苦手": "skills", "得意": "skills", "苦手": "skills", "得意なこと": "skills", "苦手なこと": "skills",
    "思い出": "memories", "思い出・その他": "memories", "その他": "memories", "メモ": "memories",
    "大事なこと": "values", "大事にしてること": "values", "大事にしていること": "values", "信条": "values",
}

# 「キー：値／キー＝値／キー→値」形式のキー別名（見出し別名と合わせて使う）
_SELF_KEY_ALIASES = {
    "名前": "basic", "氏名": "basic", "本名": "basic", "ニックネーム": "basic", "あだ名": "basic",
    "年齢": "basic", "歳": "basic", "住所": "basic", "住み": "basic", "住まい": "basic", "居住地": "basic",
    "出身": "basic", "出身地": "basic", "学校": "basic", "仕事": "basic", "職業": "basic", "勤め先": "basic",
    "誕生日": "basic", "生年月日": "basic", "血液型": "basic", "身長": "basic", "体重": "basic", "性別": "basic",
    "家族": "basic", "家族構成": "basic", "友達": "basic", "友人": "basic",
    "一人称": "speech", "方言": "speech", "声": "speech", "よく言う言葉": "speech",
    "好きな食べ物": "likes_dislikes", "好きな飲み物": "likes_dislikes", "好きなゲーム": "likes_dislikes",
    "好きなアニメ": "likes_dislikes", "好きな音楽": "likes_dislikes", "好きな色": "likes_dislikes",
    "嫌いな食べ物": "likes_dislikes", "苦手な食べ物": "likes_dislikes",
    "趣味": "likes_dislikes", "推し": "likes_dislikes", "ハマっているもの": "likes_dislikes",
    "判断基準": "thinking", "長所": "skills", "短所": "skills", "特技": "skills", "資格": "skills",
    "できること": "skills", "できないこと": "skills",
    "日課": "habits", "ルーティン": "habits", "休日の過ごし方": "habits",
    "エピソード": "memories", "経験": "memories", "備考": "memories",
    "座右の銘": "values", "目標": "values", "夢": "values", "将来の夢": "values", "大切なこと": "values",
}
_SELF_ALL_ALIASES = dict(_SELF_HEADING_ALIASES)
_SELF_ALL_ALIASES.update(_SELF_KEY_ALIASES)

_SELF_KEYWORD_RULES = [
    ("speech", ("口癖", "話し方", "語尾", "一人称", "僕は", "俺は", "私は", "って言う", "よく言う", "言葉遣い", "方言")),
    ("likes_dislikes", ("好き", "嫌い", "大好き", "苦手な食べ物", "趣味は", "食べ物", "飲み物", "ご飯", "お菓子",
                        "ゲーム", "アニメ", "マンガ", "漫画", "音楽", "映画", "スポーツ", "読書")),
    ("thinking", ("考え方", "決める", "決め方", "迷ったら", "判断", "と思う", "大事だと思うのは考え",
                  "考え", "決断", "迷った", "選ぶとき")),
    ("habits", ("いつも", "習慣", "毎日", "朝は", "夜は", "よく行く", "普段",
                "毎朝", "毎晩", "毎週", "寝る前", "起きたら", "日課")),
    ("skills", ("得意", "苦手", "できる", "できない", "上手", "下手", "特技", "資格")),
    ("values", ("大事に", "大切に", "大切", "約束", "絶対に", "譲れない", "宝物", "将来の夢")),
    ("memories", ("思い出", "昔", "子供の頃", "小さい頃", "行った", "もらった", "初めて", "卒業", "入学")),
    ("basic", ("歳", "才", "住んで", "学校", "仕事は", "名前は", "家族", "友達", "友人",
               "おじいちゃん", "おばあちゃん", "父さん", "母さん", "出身")),
]

_HEADING_RE = re.compile(r"^\s*(?:#{1,6}\s*|【|\[)([^\]】#\n]{1,30}?)(?:】|\])?\s*[:：]?\s*$")
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[。！？\n])")
_BULLET_RE = re.compile(r"^\s*(?:[・\-－*＊●○◎•◦▪▸‣➤]|[①-⑳]|\(\d{1,2}\)|（\d{1,2}）|\d{1,2}\s*[.、)）])\s*")
_DIVIDER_RE = re.compile(r"^\s*[-=~_*─―—]{3,}\s*$")
_DATE_RE = re.compile(r"^\s*(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日|\d{4}[/\-]\d{1,2}[/\-]\d{1,2}|\d{1,2}\s*月\s*\d{1,2}\s*日)"
                      r"\s*(?:[（(][月火水木金土日]曜日?[）)])?\s*[:：、]?\s*(.*)$")
_KV_RE = re.compile(r"^\s*([^:：=＝\n]{1,24}?)\s*(?:[:：]|＝|=|→|->)\s*(.+)$")
_SPEAKER_RE = re.compile(r"^\s*([^\s:：、。，！？]{1,10})\s*[:：]\s*(.+)$")
_Q_RE = re.compile(r"^\s*(?:Q|Ｑ|質問|問|問い)\s*[:：.、]?\s*(.*)$", re.IGNORECASE)
_A_RE = re.compile(r"^\s*(?:A|Ａ|答え|回答|答)\s*[:：.、]?\s*(.*)$", re.IGNORECASE)
_SELF_SPEAKERS = {"鳥", "自分", "私", "俺", "僕", "ぼく", "わたし", "ユーザー", "ユーザ",
                  "本人", "主人公", "user", "me"}
# 会話ログで「相手側」とみなす役割名（キー別名と重なっても発言者として優先する）
_OTHER_SPEAKER_NAMES = {"友達", "友人", "相手", "家族", "母", "父", "お母さん", "お父さん",
                        "先生", "店員", "先輩", "後輩", "兄", "姉", "弟", "妹"}


def _alias_for(name):
    """キー名・見出し名から項目キーを引く。完全一致のみ（前方一致だと未知キーを誤判定する）。"""
    if not name:
        return None
    n = re.sub(r"[\s　]+", "", str(name).strip().strip("#【】[]■◆●★◇□▲▶※:："))
    return _SELF_ALL_ALIASES.get(n)


def _heading_key_for(line):
    """行全体が見出し（# / 【】 / [] / 記号付き / 素の別名）なら項目キーを返す。"""
    t = (line or "").strip()
    t = re.sub(r"^#{1,6}\s*", "", t)
    t = re.sub(r"^[■◆●★◇□▲▶※]+\s*", "", t)
    m = re.match(r"^[【\[](.+)[】\]]\s*[:：]?\s*$", t)
    if m:
        return _alias_for(m.group(1))
    t2 = t.rstrip("：:").strip()
    if len(t2) <= 20 and not re.search(r"[。！？、]", t2) and t2 in _SELF_ALL_ALIASES:
        return _SELF_ALL_ALIASES[t2]
    return None


# ---------------------------------------------------------------------------
# 文字コード自動判定（どんなファイルでも文字化けさせない）
# ---------------------------------------------------------------------------

def _decode_penalty(text):
    """文字化けっぽさの罰点。�・制御文字・私用領域・半角カナの不自然な連続を数える。"""
    if not text:
        return 0
    penalty = text.count("\ufffd") * 20
    penalty += text.count("\x00") * 20
    penalty += sum(1 for ch in text if ord(ch) < 0x20 and ch not in "\n\r\t") * 5
    penalty += sum(1 for ch in text if 0xE000 <= ord(ch) <= 0xF8FF) * 3
    for m in re.finditer(r"[｡-ﾟ]{3,}", text):
        penalty += len(m.group(0)) * 2
    return penalty


def decode_text_bytes(data):
    """
    バイト列を文字列に直す純粋関数。
    UTF-8 BOM→UTF-16 BOM→UTF-8→CP932(Shift_JIS)→UTF-16 の順に試し、
    文字化け罰点が一番小さい候補を返す。全部だめなら UTF-8 errors=replace。
    """
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    if not data:
        return ""
    if data.startswith(b"\xef\xbb\xbf"):
        try:
            return data.decode("utf-8-sig")
        except Exception:
            pass
    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        try:
            return data.decode("utf-16")
        except Exception:
            pass
    candidates = []
    for enc in ("utf-8", "cp932"):
        try:
            candidates.append((enc, data.decode(enc)))
        except (UnicodeDecodeError, LookupError):
            pass
    if b"\x00" in data:
        for enc in ("utf-16", "utf-16-le", "utf-16-be"):
            try:
                candidates.append((enc, data.decode(enc)))
            except (UnicodeDecodeError, LookupError):
                pass
    if candidates:
        order = {"utf-8": 0, "cp932": 1, "utf-16": 2, "utf-16-le": 3, "utf-16-be": 4}
        best = min(candidates, key=lambda kv: (_decode_penalty(kv[1]), order.get(kv[0], 9)))
        return best[1]
    return data.decode("utf-8", errors="replace")


def empty_self_profile():
    return {k: "" for k, _ in SELF_FIELDS}


def _self_append(profile, key, sentence):
    s = (sentence or "").strip()
    if not s:
        return
    if profile.get(key):
        profile[key] = profile[key].rstrip() + "\n" + s
    else:
        profile[key] = s


def _classify_sentence(sentence):
    return _classify_sentence_ex(sentence)[0]


def _classify_sentence_ex(sentence):
    """(項目キー, キーワードに当たったか) を返す。外れたら memories で当たらなかった扱い。"""
    for key, keywords in _SELF_KEYWORD_RULES:
        for kw in keywords:
            if kw in sentence:
                return key, True
    return "memories", False


def _qa_body(line, kind):
    """Q&Aマーカー（Q:/質問：/A:/答え：等）の本文を返す。マーカーでなければ None。"""
    markers = ("質問", "問い", "問", "Q", "Ｑ") if kind == "q" else ("答え", "回答", "答", "A", "Ａ")
    s = (line or "").strip()
    for mk in markers:
        if s.startswith(mk):
            rest = s[len(mk):]
            if rest == "":
                return ""
            if rest[0] in ":：.、 　":
                return rest.lstrip(":：.、 　").strip()
            return None
    return None


def _json_value_to_text(v):
    """JSONの値を保存用テキストにする。リストは全要素を展開、入れ子dictは丸ごと残す。"""
    if isinstance(v, str):
        return v
    if isinstance(v, list):
        return "\n".join(_json_value_to_text(x) for x in v)
    if isinstance(v, dict):
        return json.dumps(v, ensure_ascii=False)
    if v is None:
        return ""
    return str(v)


def _split_sentences(text):
    parts = []
    for chunk in _SENTENCE_SPLIT_RE.split(text or ""):
        c = chunk.strip()
        if c:
            parts.append(c)
    return parts


def parse_self_profile(text):
    """
    特徴テキストを8項目に自動振り分けする。どんな書き方でも、どの文も捨てない。
    対応形式: 見出し（#/【】/[]/記号付き）/ キー：値・キー＝値・キー→値 /
    箇条書き / Q&A / 会話ログ / Markdown表 / CSV・TSV / 日記 / 改行のない長文 /
    JSON（項目キー or 日本語ラベルがキー、リスト・入れ子も全部展開）。
    空行と区切り線と表の区切り行だけは読み飛ばす。それ以外の非空テキストは全部残す。
    """
    profile = empty_self_profile()
    raw = text or ""
    stripped = raw.strip()
    if stripped.startswith("{") or stripped.startswith("["):
        try:
            data = json.loads(stripped)
        except Exception:
            data = None
        if isinstance(data, dict):
            label_to_key = {v: k for k, v in SELF_FIELDS}
            label_to_key.update(_SELF_ALL_ALIASES)
            for k, v in data.items():
                key = k if k in profile else label_to_key.get(str(k).strip())
                val = _json_value_to_text(v)
                if not val:
                    continue
                if key:
                    _self_append(profile, key, val)
                else:
                    _self_append(profile, "memories", "%s: %s" % (k, val))
            return profile
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    sub = parse_self_profile(json.dumps(item, ensure_ascii=False))
                    for kk in profile:
                        if sub.get(kk):
                            _self_append(profile, kk, sub[kk])
                else:
                    for sent in _split_sentences(_json_value_to_text(item)):
                        _self_append(profile, _classify_sentence(sent), sent)
            return profile

    current = None
    pending_q = None      # 答え待ちの質問文
    expect_q = False      # 次の行が質問文そのもの
    expect_a = False      # 次の行が答えそのもの

    def flush_q():
        nonlocal pending_q
        if pending_q:
            _self_append(profile, _classify_sentence(pending_q), pending_q)
            pending_q = None

    def answer_q(answer):
        nonlocal pending_q
        q = pending_q or ""
        key, hit = _classify_sentence_ex(answer)
        if not hit and q:
            key = _classify_sentence(q)
        entry = ("%s → %s" % (q, answer)) if q and answer else (answer or q)
        if entry:
            _self_append(profile, key, entry)
        pending_q = None

    def append_kv(key_name, value):
        """キー：値を保存する。知ってるキーはその項目、未知のキーはキー名付きで思い出へ。"""
        nonlocal current
        key = _alias_for(key_name)
        val = (value or "").strip()
        if not val:
            return key
        if key:
            for sent in _split_sentences(val):
                _self_append(profile, key, sent)
            current = key
        else:
            _self_append(profile, "memories", "%s: %s" % (str(key_name).strip(), val))
        return key

    def append_sentences(body, force_key=None):
        for sent in _split_sentences(body):
            if force_key:
                _self_append(profile, force_key, sent)
            elif current:
                _self_append(profile, current, sent)
            else:
                _self_append(profile, _classify_sentence(sent), sent)

    for line in raw.splitlines():
        s = line.strip()
        if not s:
            continue
        if _DIVIDER_RE.match(s):
            continue
        # Q&A の続き行（Q:/A: の次行に本体が来る書き方）
        if expect_q:
            pending_q = s
            expect_q = False
            continue
        if expect_a:
            expect_a = False
            answer_q(s)
            continue
        # Markdown表: | 項目 | 内容 |
        if s.startswith("|") and s.count("|") >= 2:
            cells = [c.strip() for c in s.strip().strip("|").split("|")]
            if cells and all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c != ""):
                continue  # 区切り行 |---| は捨ててよい唯一の例外
            if len(cells) >= 2 and (cells[0] or cells[1]):
                flush_q()
                append_kv(cells[0], " ".join(c for c in cells[1:] if c))
                continue
        # Q&A形式（「問題は…」「答えは…」のような普通の文を誤認しないよう、
        # マーカーの直後に区切りがある時だけQ&Aとして扱う）
        q_body = _qa_body(s, "q")
        if q_body is not None:
            flush_q()
            if q_body:
                pending_q = q_body
            else:
                expect_q = True
            continue
        a_body = _qa_body(s, "a")
        if a_body is not None:
            if a_body:
                answer_q(a_body)
            else:
                expect_a = True
            continue
        # 日記形式: 日付で始まる行は日付付きで思い出へ
        dm = _DATE_RE.match(s)
        if dm:
            flush_q()
            date = re.sub(r"\s+", "", dm.group(1))
            rest = (dm.group(2) or "").strip()
            if rest:
                _self_append(profile, "memories", "%s: %s" % (date, rest))
            else:
                _self_append(profile, "memories", date)
                current = "memories"
            continue
        # 見出しだけの行
        hk = _heading_key_for(s)
        if hk:
            flush_q()
            current = hk
            continue
        # 【見出し】内容 / [見出し] 内容（同じ行に中身がある書き方）
        bm = re.match(r"^\s*[【\[]([^】\]]{1,20})[】\]]\s*[:：]?\s*(.+)$", s)
        if bm and _alias_for(bm.group(1)):
            flush_q()
            current = _alias_for(bm.group(1))
            append_sentences(bm.group(2), force_key=current)
            continue
        # 箇条書きの行頭記号を外してから、中身を普通の行として処理する
        s = _BULLET_RE.sub("", s).strip()
        if not s:
            continue
        # CSV / TSV: 1列目=キー、2列目=値
        if "\t" in s or ("," in s and " " not in s.split(",", 1)[0]
                         and len(s.split(",", 1)[0]) <= 12 and s.split(",", 1)[0]):
            parts = re.split(r"[\t,]", s)
            if len(parts) >= 2 and parts[1].strip():
                flush_q()
                append_kv(parts[0].strip(), ", ".join(p.strip() for p in parts[1:] if p.strip()))
                continue
        # 発言者（自分/相手の役割名）→ キー：値（知ってるキー）→ 発言者（一般）→ キー：値（未知）
        sm0 = _SPEAKER_RE.match(s)
        if sm0 and (sm0.group(1).strip() in _SELF_SPEAKERS
                    or sm0.group(1).strip() in _OTHER_SPEAKER_NAMES):
            flush_q()
            name = sm0.group(1).strip()
            body = sm0.group(2).strip()
            if name in _SELF_SPEAKERS:
                append_sentences(body)
            else:
                _self_append(profile, "memories", "会話相手: （%s）%s" % (name, body))
            continue
        km = _KV_RE.match(s)
        if km and _alias_for(km.group(1)):
            flush_q()
            append_kv(km.group(1), km.group(2))
            continue
        sm = _SPEAKER_RE.match(s)
        if sm and not _alias_for(sm.group(1)):
            flush_q()
            name = sm.group(1).strip()
            body = sm.group(2).strip()
            if name.lower() in _SELF_SPEAKERS or name in _SELF_SPEAKERS:
                append_sentences(body)
            else:
                _self_append(profile, "memories", "会話相手: （%s）%s" % (name, body))
            continue
        if km:
            flush_q()
            append_kv(km.group(1), km.group(2))
            continue
        flush_q()
        append_sentences(s)
    flush_q()
    return profile


def merge_self_profile(base, extra):
    out = dict(base or empty_self_profile())
    for k in out:
        v = (extra or {}).get(k) or ""
        if v:
            _self_append(out, k, v)
    return out


def load_self_profile(path=None):
    try:
        with open(path or SELF_PROFILE_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        prof = empty_self_profile()
        if isinstance(data, dict):
            for k in prof:
                prof[k] = str(data.get(k) or "")
        return prof
    except (OSError, ValueError):
        return empty_self_profile()


def save_self_profile(profile, path=None, raw_text=None, raw_filename=None):
    ensure_data_dirs()
    p = path or SELF_PROFILE_PATH
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    if raw_text is not None:
        name = sanitize_relpath(raw_filename or "imported.txt")
        dest = safe_join(SELF_PROFILE_DIR, name)
        if dest:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "w", encoding="utf-8") as f:
                f.write(raw_text)
    return profile


def import_self_profile_file(path, chunks_path=None):
    """
    ファイル（.txt/.md/.json/.csv）をバイナリで読んで (振り分けdict, 原文) を返す。
    文字コードは decode_text_bytes で自動判定（Shift_JISでも文字化けしない）。
    取り込んだ原文はチャンクに分けて全文保存もする（append_self_chunks）。
    """
    with open(path, "rb") as f:
        data = f.read()
    raw = decode_text_bytes(data)
    try:
        append_self_chunks(os.path.basename(path), raw, path=chunks_path)
    except Exception:
        pass
    return parse_self_profile(raw), raw


# ---------------------------------------------------------------------------
# 原文の全文保存（チャンク）と、会話ごとの取り出し
# ---------------------------------------------------------------------------

def chunk_text(text, max_len=400):
    """テキストを文境界で最大 max_len 文字のチャンクに分ける純粋関数。"""
    try:
        max_len = int(max_len)
    except (TypeError, ValueError):
        max_len = 400
    if max_len <= 0:
        max_len = 400
    chunks = []
    buf = ""
    for line in (text or "").splitlines():
        for sent in _split_sentences(line):
            if len(sent) > max_len:
                if buf.strip():
                    chunks.append(buf.strip())
                    buf = ""
                for i in range(0, len(sent), max_len):
                    chunks.append(sent[i:i + max_len])
                continue
            if buf and len(buf) + len(sent) > max_len:
                chunks.append(buf.strip())
                buf = ""
            buf += sent
    if buf.strip():
        chunks.append(buf.strip())
    return chunks


def load_self_chunks(path=None):
    """保存した原文チャンクを [{source, text}, ...] で全部読む。無ければ空リスト。"""
    p = path or SELF_CHUNKS_PATH
    out = []
    try:
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                except ValueError:
                    continue
                if isinstance(d, dict) and d.get("text"):
                    out.append({"source": str(d.get("source") or ""),
                                "text": str(d.get("text"))})
    except OSError:
        pass
    return out


def append_self_chunks(source, text, path=None):
    """原文をチャンクに分けて self_profile_chunks.jsonl へ追記保存する。追記数を返す。"""
    p = path or SELF_CHUNKS_PATH
    chunks = chunk_text(text)
    if not chunks:
        return 0
    try:
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(p, "a", encoding="utf-8") as f:
            for c in chunks:
                f.write(json.dumps({"source": str(source or ""), "text": c},
                                   ensure_ascii=False) + "\n")
    except OSError:
        return 0
    return len(chunks)


def _ngram_terms(text):
    """日本語n-gram（2〜4文字）の集合。queryとの重なり採点用。"""
    cleaned = re.sub(r"[\s、。,．・/／!！?？「」『』（）()【】<>＜＞]+", "", text or "")
    terms = set()
    for n in (4, 3, 2):
        for i in range(0, max(0, len(cleaned) - n + 1)):
            terms.add(cleaned[i:i + n])
    return terms


def build_self_context(profile, query="", max_chars=3000):
    """
    自分コピーの8項目から、会話に渡すテキストを組み立てる純粋関数。
    全部入るなら全部入れる。収まらない場合は、項目ごとに均等に切るのではなく、
    query との日本語n-gram重なりで文単位に優先順位を付けて max_chars まで詰める
    （query が空なら先頭から）。戻り値は必ず max_chars 以下。
    """
    if not profile:
        return ""
    try:
        max_chars = int(max_chars)
    except (TypeError, ValueError):
        max_chars = 3000
    if max_chars <= 0:
        return ""
    units = []  # (field_idx, unit_idx, key, label, sentence)
    for fi, (key, label) in enumerate(SELF_FIELDS):
        v = (profile.get(key) or "").strip()
        if not v:
            continue
        ui = 0
        for line in v.splitlines():
            for sent in _split_sentences(line):
                units.append((fi, ui, key, label, sent))
                ui += 1
    if not units:
        return ""
    qterms = _ngram_terms(query) if query else set()
    scored = []
    for u in units:
        score = 0
        if qterms:
            uterms = _ngram_terms(u[4])
            score = sum(len(t) for t in (qterms & uterms))
        scored.append((score, u))
    if query and any(s > 0 for s, _u in scored):
        priority = sorted(scored, key=lambda su: (-su[0], su[1][0], su[1][1]))
    else:
        priority = list(scored)
    selected = []
    used_fields = set()
    total = 0
    for _score, u in priority:
        overhead = len(u[4]) + 1
        if u[2] not in used_fields:
            overhead += len(u[3]) + 4
        if selected and total + overhead > max_chars:
            continue
        if not selected and overhead > max_chars:
            trunc = u[4][:max(0, max_chars - len(u[3]) - 4)]
            if trunc:
                selected.append((u[0], u[1], u[2], u[3], trunc))
            break
        selected.append(u)
        used_fields.add(u[2])
        total += overhead
    selected.sort(key=lambda u: (u[0], u[1]))
    lines = []
    cur_key = None
    for _fi, _ui, key, label, sent in selected:
        if key != cur_key:
            lines.append("＜%s＞" % label)
            cur_key = key
        lines.append(sent)
    out = "\n".join(lines)
    return out[:max_chars] if len(out) > max_chars else out


def build_self_section(self_profile, copy_mode=False, query=""):
    """自分コピーだけのセクション（性格とは別枠で注入する）。"""
    if not self_profile:
        return ""
    has_any = any((self_profile.get(k) or "").strip() for k, _ in SELF_FIELDS)
    if not has_any:
        return ""
    lines = []
    lines.append("【自分コピー：ユーザー本人（鳥）の特徴データ】")
    lines.append("以下はユーザー本人の特徴です。このデータをよく分かった上で答えてください。性格設定とは別の、本人の情報です。")
    ctx = build_self_context(self_profile, query=query)
    if ctx:
        lines.append(ctx)
    if copy_mode:
        lines.append("【自分コピーモードON】あなたは今、鳥の分身（コピー）として答えます。")
        lines.append("一人称・口癖・話し方は上の「話し方・口癖」をそのまま使い、鳥本人として一人称で答えてください。")
        lines.append("決め方や考え方の相談では、上の「考え方・決め方」に従って鳥らしく判断し、理由も鳥の言葉で述べてください。")
        lines.append("好き嫌い・大事なことも鳥のものとして扱い、鳥が言いそうな返信文案や文章を作ってください。")
    return "\n".join(lines)


def build_full_system_prompt(persona=None, self_profile=None, copy_mode=False, cfg=None, query=""):
    """性格セクション + 自分コピーセクション + 共通追加指示を別枠のまま組み立てる。"""
    cfg = cfg or {}
    parts = []
    persona_sec = build_persona_section(persona) if persona else ""
    if persona_sec:
        parts.append(persona_sec)
    else:
        parts.append("あなたはジャービス。鳥のPCに住む、落ち着いた有能な執事AIです。やさしい日本語で、簡潔に答えてください。")
    self_sec = build_self_section(self_profile, copy_mode=copy_mode, query=query)
    if self_sec:
        parts.append(self_sec)
    if cfg.get("system_extra"):
        parts.append("【共通の追加指示】" + str(cfg["system_extra"]))
    return "\n\n".join(parts)


def build_persona_reminder(persona):
    prof = (persona or {}).get("profile") or {}
    name = (persona or {}).get("display_name") or (persona or {}).get("input_word") or "相手"
    lines = ["【最重要】あなたは今から「%s」として答えます。説明や素の話し方は禁止です。" % name]
    for key, label in (("speech", "口調・一人称・語尾・口癖"), ("traits", "性格"), ("rules", "決まり")):
        v = (prof.get(key) or "").strip()
        if v:
            lines.append("%s: %s" % (label, v[:300]))
    ex = [e.strip() for e in (prof.get("examples") or "").split("\n") if e.strip()]
    if ex:
        lines.append("セリフの見本: %s" % ex[0][:200])
    lines.append("この性格・口調を絶対に崩さずに、次の返事をしてください。")
    return "\n".join(lines)


def build_example_turns(persona):
    prof = (persona or {}).get("profile") or {}
    turns = []
    greeting = (prof.get("greeting") or "").strip()
    if greeting:
        turns.append(("user", "自己紹介して"))
        turns.append(("assistant", greeting))
    ex = [e.strip() for e in (prof.get("examples") or "").split("\n") if e.strip()]
    if ex:
        turns.append(("user", "一言どうぞ"))
        turns.append(("assistant", ex[0]))
    return turns


def load_facts(path=None):
    try:
        with open(path or FACTS_PATH, encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""


def save_facts(text, path=None):
    ensure_data_dirs()
    with open(path or FACTS_PATH, "w", encoding="utf-8") as f:
        f.write(text or "")


# ===========================================================================
# 会話記憶（SQLite 全件保存 + 日本語n-gram検索）
# ===========================================================================

class MemoryDB:
    def __init__(self, path=None):
        self.path = path or MEMORY_DB_PATH
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.Lock()
        with self._lock:
            con = sqlite3.connect(self.path)
            con.execute("""CREATE TABLE IF NOT EXISTS messages(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                personality_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL)""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_p ON messages(personality_id, id)")
            con.commit()
            con.close()

    def _con(self):
        return sqlite3.connect(self.path)

    def add(self, personality_id, role, content):
        with self._lock:
            con = self._con()
            con.execute("INSERT INTO messages(personality_id, role, content, created_at) VALUES(?,?,?,?)",
                        (personality_id, role, content, datetime.now().isoformat(timespec="seconds")))
            con.commit()
            con.close()

    def recent(self, personality_id, limit_turns):
        con = self._con()
        rows = con.execute("SELECT role, content FROM messages WHERE personality_id=? ORDER BY id DESC LIMIT ?",
                           (personality_id, max(2, int(limit_turns) * 2))).fetchall()
        con.close()
        return [(r, c) for r, c in reversed(rows)]

    @staticmethod
    def _search_terms(query):
        q = (query or "").strip()
        terms = set()
        for w in re.split(r"[\s、。,．・/／!！?？]+", q):
            if len(w) >= 2:
                terms.add(w)
        cleaned = re.sub(r"[\s、。,．・/／!！?？「」『』（）()]+", "", q)
        for n in (4, 3):
            for i in range(0, max(0, len(cleaned) - n + 1)):
                terms.add(cleaned[i:i + n])
        return sorted(terms, key=len, reverse=True)[:40]

    def search(self, personality_id, query, limit=20):
        terms = self._search_terms(query)
        if not terms:
            return []
        con = self._con()
        scores, rows_by_id = {}, {}
        for w in terms:
            rows = con.execute(
                "SELECT id, role, content, created_at FROM messages WHERE personality_id=? AND content LIKE ? ORDER BY id DESC LIMIT 50",
                (personality_id, "%" + w + "%")).fetchall()
            for row in rows:
                rows_by_id[row[0]] = row
                scores[row[0]] = scores.get(row[0], 0) + len(w)
        con.close()
        ranked = sorted(scores.items(), key=lambda kv: (kv[1], kv[0]), reverse=True)[:limit]
        found = [rows_by_id[i] for i, _s in ranked]
        found.sort(key=lambda r: r[0])
        return found

    def count(self, personality_id=None):
        con = self._con()
        if personality_id:
            n = con.execute("SELECT COUNT(*) FROM messages WHERE personality_id=?", (personality_id,)).fetchone()[0]
        else:
            n = con.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        con.close()
        return n

    def all_messages(self, personality_id):
        con = self._con()
        rows = con.execute("SELECT role, content, created_at FROM messages WHERE personality_id=? ORDER BY id",
                           (personality_id,)).fetchall()
        con.close()
        return rows


def assemble_context(memory, persona, self_profile, user_input, cfg,
                     facts_text="", web_context=""):
    """system（性格+自分コピー別枠）と turns（会話例先行+直近+再注入）を組み立てる。"""
    copy_mode = bool(cfg.get("copy_mode", False))
    system = build_full_system_prompt(persona, self_profile, copy_mode, cfg, query=user_input)
    if cfg.get("facts_enabled", True) and facts_text:
        system += "\n\n【ずっと覚えているメモ（一言一句）】\n" + facts_text
    if web_context:
        system += "\n\n" + web_context
    pid = (persona or {}).get("id") or "__default__"
    retrieved = memory.search(pid, user_input, limit=int(cfg.get("retrieve_count", 6)) * 2)
    recent = memory.recent(pid, int(cfg.get("recent_turns", 40)))
    recent_set = set((r, c) for r, c in recent)
    name = (persona or {}).get("display_name") or "相手"
    memory_lines = []
    for _id, role, content, ts in retrieved:
        if (role, content) in recent_set:
            continue
        who = cfg.get("user_name", "鳥") if role == "user" else name
        memory_lines.append("%s: %s" % (who, content))
    if memory_lines:
        keep = memory_lines[-int(cfg.get("retrieve_count", 6)) * 2:]
        system += ("\n\n【過去の会話の記録（一言一句そのまま）】\n" + "\n".join(keep))
    turns = list(recent) + [("user", user_input)]
    strength = str(cfg.get("persona_strength", "max") or "max").lower()
    if persona and strength in ("strong", "max"):
        turns = build_example_turns(persona) + turns
        turns = turns + [("system", build_persona_reminder(persona))]
    if copy_mode and self_profile and any((self_profile.get(k) or "").strip() for k, _ in SELF_FIELDS):
        turns = turns + [("system", "【再確認】自分コピーモードです。鳥本人の一人称・口癖・考え方で答えてください。")]
    return system, turns


# ===========================================================================
# 会話中の Web 検索（SarashinaChat 方式: DDG Lite → Wikipedia）
# ===========================================================================

def _http_get_text(url, timeout=15):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) JarvisPC3/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
        ctype = r.headers.get_content_charset() or "utf-8"
    return raw.decode(ctype, "replace")


def _strip_tags(html_text):
    t = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", html_text)
    t = re.sub(r"(?s)<[^>]+>", " ", t)
    t = urllib.parse.unquote(t)
    import html as _html
    t = _html.unescape(t)
    return re.sub(r"\s+", " ", t).strip()


def parse_ddg_lite(html_text, max_results=5):
    out = []
    links = re.findall(r'class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', html_text, re.S)
    snippets = re.findall(r'class="result-snippet"[^>]*>(.*?)</td>', html_text, re.S)
    for i, (href, title) in enumerate(links[:max_results]):
        url = href
        if url.startswith("//"):
            url = "https:" + url
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        if "uddg" in qs:
            url = qs["uddg"][0]
        snippet = _strip_tags(snippets[i]) if i < len(snippets) else ""
        out.append({"title": _strip_tags(title), "url": url, "snippet": snippet})
    return out


FORCE_PREFIXES = ("調べて:", "調べて：", "検索して:", "検索して：")


def split_force_prefix(text):
    t = (text or "").strip()
    for p in FORCE_PREFIXES:
        if t.startswith(p):
            return t[len(p):].strip(), True
    return t, False


def should_search(user_input, cfg, force=False):
    mode = str(cfg.get("web_mode", "auto") or "auto").lower()
    if mode == "off":
        return False
    if force or mode == "always":
        return True
    keywords = [k.strip() for k in str(cfg.get("web_keywords", "")).split(",") if k.strip()]
    return any(k in user_input for k in keywords)


def web_search(query, max_results=5, timeout=15):
    query = (query or "").strip()
    if not query:
        return []
    try:
        url = "https://lite.duckduckgo.com/lite/?q=" + urllib.parse.quote(query)
        res = parse_ddg_lite(_http_get_text(url, timeout), max_results)
        if res:
            return res
    except Exception:
        pass
    hit = web_research(query)
    if hit:
        return [{"title": hit["title"], "url": hit["url"], "snippet": hit["extract"][:400]}]
    return []


def fetch_page_text(url, max_chars=1200, timeout=15):
    try:
        return _strip_tags(_http_get_text(url, timeout))[:max_chars]
    except Exception:
        return ""


def build_web_context(query, cfg, search_fn=None, fetch_fn=None):
    search_fn = search_fn or web_search
    fetch_fn = fetch_fn or fetch_page_text
    results = search_fn(query, int(cfg.get("web_max_results", 5)))
    if not results:
        return "", []
    max_chars = int(cfg.get("web_snippet_chars", 1200))
    n_fetch = int(cfg.get("web_fetch_pages", 2))
    lines = ["【Webで調べた情報（今日の日付は %s です。答える時はこの情報を優先し、"
             "使った情報の番号とURLを文の最後に書いてください）】"
             % datetime.now().strftime("%Y-%m-%d")]
    sources = []
    for i, r in enumerate(results, 1):
        body = ""
        if i <= n_fetch:
            body = fetch_fn(r["url"], max_chars)
        text = body or r.get("snippet", "")
        lines.append("[%d] %s\nURL: %s\n%s" % (i, r.get("title", ""), r.get("url", ""), text[:max_chars]))
        sources.append({"title": r.get("title", ""), "url": r.get("url", "")})
    return "\n\n".join(lines), sources


# ===========================================================================
# llama.cpp（llama-server, 127.0.0.1）— Sarashina形式 + OpenAI互換の両対応
# ===========================================================================

def _http(url, data=None, timeout=10):
    req = urllib.request.Request(url, data=data, method="POST" if data is not None else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


class LlamaServer:
    def __init__(self, cfg):
        self.cfg = cfg
        self.proc = None
        self.started_by_us = False

    @property
    def base(self):
        return "http://127.0.0.1:%d" % int(self.cfg.get("port", 8080))

    def healthy(self, timeout=1.5):
        try:
            req = urllib.request.Request(self.base + "/health")
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status == 200
        except Exception:
            return False

    def start(self, model_path, on_status):
        if self.healthy():
            on_status("ready", "llama-server は既に動いています")
            return True
        exe = llama_server_exe(self.cfg)
        if not os.path.isfile(exe):
            on_status("error", "llama-server が見つかりません: %s" % exe)
            return False
        if not model_path or not os.path.isfile(model_path):
            on_status("error", "モデル（GGUF）が見つかりません。設定でモデルを選んでください")
            return False
        args = [exe, "-m", model_path, "--host", "127.0.0.1",
                "--port", str(int(self.cfg.get("port", 8080))),
                "-c", str(int(self.cfg.get("context_size", 8192))),
                "--threads", str(int(self.cfg.get("threads", 4)))]
        mmproj = self.cfg.get("mmproj_path") or ""
        if mmproj and os.path.isfile(mmproj):
            args += ["--mmproj", mmproj]
        try:
            ensure_data_dirs()
            logf = open(os.path.join(LOG_DIR, "llama-server.log"), "ab")
            self.proc = hidden_popen(args, stdout=logf, stderr=logf)
            self.started_by_us = True
        except Exception as e:
            on_status("error", "llama-server を起動できませんでした: %s" % e)
            return False
        on_status("loading", "モデルを読み込んでいます…")
        for _ in range(240):
            if self.proc.poll() is not None:
                on_status("error", "llama-server が途中で終了しました。logs/llama-server.log を見てください")
                return False
            if self.healthy():
                on_status("ready", "準備ができました")
                return True
            time.sleep(1.0)
        on_status("error", "サーバーの準備が時間内に終わりませんでした")
        return False

    def stop(self):
        if self.proc is not None and self.started_by_us:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=5)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
        self.proc = None
        self.started_by_us = False


class LlamaClient:
    """api_mode=sarashina なら /completion + 形式プロンプト、openai なら /v1/chat/completions。"""

    def __init__(self, cfg):
        self.cfg = cfg

    @property
    def base(self):
        return "http://127.0.0.1:%d" % int(self.cfg.get("port", 8080))

    def generate_stream(self, system, turns, on_token=None, stop_event=None,
                        n_predict=None, temperature=None):
        stop_event = stop_event or threading.Event()
        if str(self.cfg.get("api_mode", "sarashina")).lower() == "openai":
            return self._generate_openai(system, turns, on_token, stop_event, n_predict, temperature)
        return self._generate_sarashina(system, turns, on_token, stop_event, n_predict, temperature)

    def _payload_common(self, n_predict, temperature):
        return {
            "n_predict": int(self.cfg.get("n_predict", 1024) if n_predict is None else n_predict),
            "temperature": float(self.cfg.get("temperature", 0.7) if temperature is None else temperature),
            "top_p": float(self.cfg.get("top_p", 0.95)),
            "top_k": int(self.cfg.get("top_k", 40)),
            "repeat_penalty": float(self.cfg.get("repeat_penalty", 1.1)),
            "repeat_last_n": int(self.cfg.get("repeat_last_n", 64)),
            "min_p": float(self.cfg.get("min_p", 0.05)),
            "seed": int(self.cfg.get("seed", -1)),
        }

    def _generate_sarashina(self, system, turns, on_token, stop_event, n_predict, temperature):
        payload = self._payload_common(n_predict, temperature)
        payload.update({
            "prompt": build_sarashina_prompt(system, turns),
            "stop": ["</s>"] + [s for s in str(self.cfg.get("custom_stop", "")).split(",") if s.strip()],
            "stream": True,
            "cache_prompt": True,
        })
        req = urllib.request.Request(self.base + "/completion",
                                     data=json.dumps(payload).encode("utf-8"), method="POST")
        req.add_header("Content-Type", "application/json")
        out = []
        with urllib.request.urlopen(req, timeout=3600) as r:
            for raw in r:
                if stop_event.is_set():
                    break
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                try:
                    data = json.loads(line[5:])
                except ValueError:
                    continue
                content = data.get("content", "")
                if content:
                    out.append(content)
                    if on_token:
                        on_token(content)
                if data.get("stop"):
                    break
        return strip_think("".join(out).strip())

    def _generate_openai(self, system, turns, on_token, stop_event, n_predict, temperature):
        payload = {
            "messages": build_openai_messages(system, turns),
            "max_tokens": int(self.cfg.get("n_predict", 1024) if n_predict is None else n_predict),
            "temperature": float(self.cfg.get("temperature", 0.7) if temperature is None else temperature),
            "stream": True,
        }
        req = urllib.request.Request(self.base + "/v1/chat/completions",
                                     data=json.dumps(payload).encode("utf-8"), method="POST")
        req.add_header("Content-Type", "application/json")
        out = []
        with urllib.request.urlopen(req, timeout=3600) as r:
            for raw in r:
                if stop_event.is_set():
                    break
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                body = line[5:].strip()
                if body == "[DONE]":
                    break
                try:
                    data = json.loads(body)
                except ValueError:
                    continue
                try:
                    content = data["choices"][0]["delta"].get("content", "") or ""
                except Exception:
                    content = ""
                if content:
                    out.append(content)
                    if on_token:
                        on_token(content)
        return strip_think("".join(out).strip())

    def generate_once(self, system, user_text, n_predict=1400, temperature=0.3):
        return self.generate_stream(system, [("user", user_text)], None,
                                    threading.Event(), n_predict=n_predict,
                                    temperature=temperature)

    def chat_vision(self, system, question, image_b64, mime="image/jpeg"):
        payload = {
            "messages": build_vision_messages(question, image_b64, mime),
            "max_tokens": int(self.cfg.get("n_predict", 1024)),
            "temperature": float(self.cfg.get("temperature", 0.7)),
        }
        if system:
            payload["messages"] = [{"role": "system", "content": system}] + payload["messages"]
        req = urllib.request.Request(self.base + "/v1/chat/completions",
                                     data=json.dumps(payload).encode("utf-8"), method="POST")
        req.add_header("Content-Type", "application/json")
        with urllib.request.urlopen(req, timeout=600) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        try:
            return strip_think(data["choices"][0]["message"]["content"].strip())
        except Exception:
            return ""


def chat_once(memory, cfg, persona, self_profile, user_text, client):
    raw = (user_text or "").strip()
    text, forced = split_force_prefix(raw)
    if not text:
        text = raw
    eff = effective_config(cfg, persona)
    web_context, sources = "", []
    if should_search(text, eff, force=forced):
        try:
            web_context, sources = build_web_context(text, eff)
        except Exception:
            web_context, sources = "", []
    system, turns = assemble_context(memory, persona, self_profile, text, eff,
                                     facts_text=load_facts(), web_context=web_context)
    pid = (persona or {}).get("id") or "__default__"
    memory.add(pid, "user", raw)
    reply = client.generate_stream(system, turns, None, threading.Event())
    if reply:
        memory.add(pid, "assistant", reply)
    return reply, sources


# ===========================================================================
# 作る力（エージェント）— 純粋ロジック
# ===========================================================================

MAKER_MAX_RETRIES = 3

_MAKER_FILE_RE = re.compile(r"^\s*(?:ファイル|file)\s*[:：]\s*(.+?)\s*$", re.IGNORECASE)
_MAKER_ELEM_RE = re.compile(r"^\s*[-・*＊]\s*(.+?)\s*$")
_FENCE_START_RE = re.compile(r"^\s*```")


def parse_maker_plan(text):
    """
    形式:
      要素:
      - 要素1
      ファイル: 名前.py
      ``` ... 中身 ... ```
    戻り値: {"elements": [...], "files": [{"name":..., "body":...}]}
    """
    plan = {"elements": [], "files": []}
    cleaned = strip_think(text or "")
    section = None
    cur_name = None
    in_fence = False
    buf = []
    for line in cleaned.splitlines():
        if in_fence:
            if _FENCE_START_RE.match(line):
                plan["files"].append({"name": cur_name or "無題.txt",
                                       "body": "\n".join(buf).strip("\n")})
                cur_name, buf, in_fence = None, [], False
            else:
                buf.append(line)
            continue
        if _FENCE_START_RE.match(line):
            in_fence = True
            buf = []
            continue
        fm = _MAKER_FILE_RE.match(line)
        if fm:
            cur_name = sanitize_relpath(fm.group(1))
            section = "file"
            continue
        if re.match(r"^\s*(要素|elements?)\s*[:：]?\s*$", line, re.IGNORECASE):
            section = "elements"
            continue
        em = _MAKER_ELEM_RE.match(line)
        if em and section == "elements":
            plan["elements"].append(em.group(1).strip())
            continue
        if section == "file" and cur_name and line.strip():
            buf.append(line)
    if cur_name and buf:
        plan["files"].append({"name": cur_name, "body": "\n".join(buf).strip("\n")})
    elif in_fence and cur_name:
        plan["files"].append({"name": cur_name, "body": "\n".join(buf).strip("\n")})
    return plan


def verify_created_file(path):
    """.py: py_compile / .json: json.loads / .html: タグ対応 / .md/.txt: 非空。(ok, message)"""
    if not path or not os.path.isfile(path):
        return False, "ファイルがありません: %s" % path
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
    except OSError as e:
        return False, "読めませんでした: %s" % e
    if ext == ".py":
        import py_compile
        try:
            py_compile.compile(path, doraise=True)
            return True, "Python構文OK"
        except Exception as e:
            return False, "Python構文エラー: %s" % e
    if ext == ".json":
        try:
            json.loads(content)
            return True, "JSON OK"
        except Exception as e:
            return False, "JSONエラー: %s" % e
    if ext in (".html", ".htm"):
        return _verify_html(content)
    if ext in (".md", ".txt"):
        if content.strip():
            return True, "中身あり（%d文字）" % len(content)
        return False, "中身が空です"
    if not content.strip() and ext not in (".png", ".jpg", ".jpeg", ".gif", ".wav", ".mp3"):
        return False, "中身が空です"
    return True, "存在確認OK"


_VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input",
              "link", "meta", "param", "source", "track", "wbr"}
_TAG_RE = re.compile(r"<(/?)([a-zA-Z][a-zA-Z0-9]*)\b[^>]*?(/?)>")


def _verify_html(content):
    if not content.strip():
        return False, "中身が空です"
    stack = []
    for m in _TAG_RE.finditer(content):
        closing, name, selfclose = m.group(1), m.group(2).lower(), m.group(3)
        if name in _VOID_TAGS or selfclose:
            continue
        if closing:
            if not stack:
                return False, "閉じタグ </%s> に対応する開きタグがありません" % name
            if stack[-1] != name:
                return False, "タグの対応がずれています: <%s> に対して </%s>" % (stack[-1], name)
            stack.pop()
        else:
            stack.append(name)
    if stack:
        return False, "閉じていないタグがあります: %s" % ", ".join(stack)
    return True, "HTMLタグ対応OK"


def build_checklist_report(plan, results):
    lines = ["=== 作る力レポート ==="]
    files = plan.get("files") or []
    blob = "\n".join((f.get("name", "") + "\n" + f.get("body", "")) for f in files)
    elements = plan.get("elements") or []
    if elements:
        lines.append("要素リスト照合（ファイル名と中身に言葉が含まれるかで判定・目安）:")
        for el in elements:
            hit = el in blob or any(tok and tok in blob for tok in re.split(r"[\s、,・]+", el) if len(tok) >= 2)
            lines.append("  %s %s" % ("○" if hit else "×", el))
    else:
        lines.append("要素リスト: （計画に要素リストがありませんでした）")
    lines.append("ファイル検証:")
    all_ok = True
    for r in results:
        lines.append("  %s %s — %s" % ("○" if r.get("ok") else "×", r.get("name", ""), r.get("message", "")))
        all_ok = all_ok and bool(r.get("ok"))
    lines.append("結果: %s" % ("全部OK" if (results and all_ok) else "未完成の部分があります（正直報告）"))
    return "\n".join(lines)


def maker_loop(client, system, request_text, workspace_dir, cfg=None,
               on_step=None, generate_fn=None):
    """計画→生成→検証→最大 MAKER_MAX_RETRIES 回まで自動修正。(report, results)"""
    cfg = cfg or {}
    max_retries = int(cfg.get("maker_max_retries", MAKER_MAX_RETRIES))
    max_retries = max(0, min(max_retries, MAKER_MAX_RETRIES))
    on_step = on_step or (lambda m: None)
    if generate_fn is None:
        def generate_fn(sys_prompt, prompt):
            return client.generate_once(sys_prompt, prompt, n_predict=2048, temperature=0.4)
    os.makedirs(workspace_dir, exist_ok=True)
    on_step("要素リストとファイル計画を作っています…")
    plan_prompt = (
        "次の頼みで作る物の計画を、下の形式だけで書いてください。\n"
        "要素:\n- （必要な要素を箇条書き）\n"
        "ファイル: ファイル名\n```\n（ファイルの中身全部）\n```\n"
        "ファイルが複数あれば同じ形を繰り返してください。\n頼み: %s" % request_text)
    raw = generate_fn(system, plan_prompt)
    plan = parse_maker_plan(raw)
    if not plan["files"]:
        plan["files"] = [{"name": "作ったもの.txt", "body": strip_think(raw)}]
    results = []
    for f in plan["files"]:
        dest = safe_join(workspace_dir, f["name"])
        if dest is None:
            results.append({"name": f["name"], "ok": False, "message": "安全のため書き込めませんでした"})
            continue
        body = f["body"]
        ok, msg = False, ""
        for attempt in range(max_retries + 1):
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "w", encoding="utf-8") as fh:
                fh.write(body)
            ok, msg = verify_created_file(dest)
            if ok:
                break
            if attempt < max_retries:
                on_step("%s の検証で問題が出たので直します（%d回目）: %s" % (f["name"], attempt + 1, msg))
                fix_prompt = (
                    "次のファイルの検証でエラーが出ました。直した中身だけを、"
                    "ファイル: %s の形式＋コードブロックで返してください。\n"
                    "エラー: %s\n今の中身:\n```\n%s\n```" % (f["name"], msg, body))
                fixed = parse_maker_plan(generate_fn(system, fix_prompt))
                if fixed["files"]:
                    body = fixed["files"][0]["body"]
                else:
                    break
        results.append({"name": f["name"], "ok": ok, "message": msg})
    report = build_checklist_report(plan, results)
    return report, results


# ===========================================================================
# 視覚・ページ理解の純粋部分（v2 継承）
# ===========================================================================

def parse_vision_coords(text):
    cleaned = strip_think(text or "")
    found = _NUM_RE.findall(cleaned)
    if len(found) < 2:
        return None
    try:
        x = float(found[0]) / 10.0
        y = float(found[1]) / 10.0
    except ValueError:
        return None
    return (max(0.0, min(100.0, x)), max(0.0, min(100.0, y)))


def build_vision_messages(question, image_b64, mime="image/jpeg"):
    return [{
        "role": "user",
        "content": [
            {"type": "text", "text": question},
            {"type": "image_url",
             "image_url": {"url": "data:%s;base64,%s" % (mime, image_b64)}},
        ],
    }]


BROWSER_CLASS_NAMES = {"Chrome_WidgetWin_1", "Chrome_WidgetWin_0", "MozillaWindowClass"}
BROWSER_TITLE_HINTS = ("Google Chrome", "Microsoft Edge", "Mozilla Firefox",
                       "Brave", "Chromium", "Opera", "Vivaldi")


def is_browser_window(title, class_name):
    if class_name and class_name.strip() in BROWSER_CLASS_NAMES:
        return True
    t = title or ""
    return any(h in t for h in BROWSER_TITLE_HINTS)


def cleanup_page_text(text, max_chars=6000):
    seen = set()
    lines = []
    for line in (text or "").splitlines():
        s = line.strip()
        if not s or s in seen:
            continue
        seen.add(s)
        lines.append(s)
    out = "\n".join(lines)
    if len(out) > max_chars:
        out = out[:max_chars]
    return out


VIDEO_SIZE_TATE = (1080, 1920)
VIDEO_SIZE_YOKO = (1280, 720)
VIDEO_MAX_SCENES = 8

VIDEO_SCRIPT_SYSTEM = (
    "あなたは説明動画の台本作家です。頼まれたテーマについて台本を書いてください。"
    "場面は4つから6つ。必ず下の形式だけで答えてください。\n"
    "---場面---\nタイトル: 見出し\n絵: ロボット、パソコン、フォルダ、時計、本、電球、歯車 の中から1つ\n"
    "スライド:\n・短い箇条書き\nナレーション: 読み上げる文章。2〜4文。")

_SCENE_SEP_RE = re.compile(r"^\s*-{2,}\s*場面\s*-{2,}\s*$")
_VIDEO_FIELD_RE = re.compile(r"^\s*(タイトル|絵|スライド|ナレーション)\s*[:：]\s*(.*)$")


def parse_video_script(text):
    cleaned = strip_think(text or "")
    blocks, cur = [], None
    for line in cleaned.splitlines():
        if _SCENE_SEP_RE.match(line):
            if cur is not None:
                blocks.append(cur)
            cur = []
            continue
        if cur is not None:
            cur.append(line)
    if cur is not None:
        blocks.append(cur)
    scenes = []
    for block in blocks:
        scene = {"title": "", "motif_raw": "", "bullets": [], "narration": ""}
        field, narration_lines = None, []
        for line in block:
            m = _VIDEO_FIELD_RE.match(line)
            if m:
                field = m.group(1)
                rest = m.group(2).strip()
                if field == "タイトル":
                    scene["title"] = rest
                elif field == "絵":
                    scene["motif_raw"] = rest
                elif field == "ナレーション" and rest:
                    narration_lines.append(rest)
                continue
            s = line.strip()
            if not s:
                continue
            if field == "スライド":
                b = re.sub(r"^[・\-*＊>＞\s]+", "", s).strip()
                if b:
                    scene["bullets"].append(b)
            elif field == "ナレーション":
                narration_lines.append(s)
        scene["narration"] = " ".join(narration_lines).strip()
        scene["bullets"] = scene["bullets"][:4]
        if scene["title"] or scene["narration"]:
            scenes.append(scene)
    return scenes


MOTIF_NAMES = ("robot", "checklist", "laptop", "keyboard", "enter", "folder",
               "document", "magnifier", "clock", "book", "bulb", "gear")
_MOTIF_JA = {
    "ロボット": "robot", "チェックリスト": "checklist", "パソコン": "laptop",
    "キーボード": "keyboard", "エンター": "enter", "フォルダ": "folder",
    "ファイル": "document", "虫めがね": "magnifier", "時計": "clock",
    "本": "book", "電球": "bulb", "歯車": "gear",
}


def choose_motif(explicit="", text=""):
    e = (explicit or "").strip()
    if e:
        if e.lower() in MOTIF_NAMES:
            return e.lower()
        for ja, name in _MOTIF_JA.items():
            if ja in e:
                return name
    return "document"


def ffmpeg_exe_path():
    if _imageio_ffmpeg is not None:
        try:
            p = _imageio_ffmpeg.get_ffmpeg_exe()
            if p and os.path.isfile(p):
                return p
        except Exception:
            pass
    return shutil.which("ffmpeg")


# ===========================================================================
# 読み上げ（VOICEVOX → SAPI。v2 継承）
# ===========================================================================

VOICEVOX_BASE = "http://127.0.0.1:50021"
DEFAULT_SPEAKER = 11


def detect_voicevox(timeout=1.5):
    try:
        req = urllib.request.Request(VOICEVOX_BASE + "/version")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8", "replace").strip().strip('"')
    except Exception:
        return None


def _split_sentences(text, max_len=120):
    text = re.sub(r"\s+", " ", (text or "")).strip()
    if not text:
        return []
    chunks, buf = [], ""
    for part in re.split(r"(?<=[。！？!?\n])", text):
        if not part:
            continue
        if len(buf) + len(part) > max_len and buf:
            chunks.append(buf)
            buf = part
        else:
            buf += part
    if buf:
        chunks.append(buf)
    out = []
    for c in chunks:
        while len(c) > max_len:
            out.append(c[:max_len])
            c = c[max_len:]
        if c:
            out.append(c)
    return out


class VoiceEngine:
    def __init__(self, speaker_id=DEFAULT_SPEAKER):
        self.speaker_id = speaker_id
        self._stop = threading.Event()
        self._thread = None
        self._sapi_proc = None
        self._lock = threading.Lock()

    def speak_async(self, text, on_done=None):
        self.stop()
        self._stop.clear()
        self._thread = threading.Thread(target=self._speak_all, args=(text, on_done), daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if _winsound is not None:
            try:
                _winsound.PlaySound(None, _winsound.SND_PURGE)
            except Exception:
                pass
        with self._lock:
            proc, self._sapi_proc = self._sapi_proc, None
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass

    def is_speaking(self):
        return self._thread is not None and self._thread.is_alive()

    def _speak_all(self, text, on_done):
        ok = False
        try:
            for chunk in _split_sentences(text):
                if self._stop.is_set():
                    break
                if self._speak_voicevox(chunk):
                    ok = True
                    continue
                if self._stop.is_set():
                    break
                if self._speak_sapi(chunk):
                    ok = True
        except Exception:
            ok = False
        if on_done is not None:
            try:
                on_done(ok)
            except Exception:
                pass

    def _speak_voicevox(self, text):
        try:
            q = urllib.parse.urlencode({"text": text, "speaker": int(self.speaker_id)})
            raw = _http(VOICEVOX_BASE + "/audio_query?" + q, data=b"", timeout=15)
            query = json.loads(raw.decode("utf-8"))
            body = json.dumps(query).encode("utf-8")
            q2 = urllib.parse.urlencode({"speaker": int(self.speaker_id)})
            req = urllib.request.Request(VOICEVOX_BASE + "/synthesis?" + q2, data=body, method="POST")
            req.add_header("Content-Type", "application/json")
            with urllib.request.urlopen(req, timeout=60) as r:
                wav = r.read()
            if not wav or _winsound is None:
                return False
            import tempfile
            fd, path = tempfile.mkstemp(suffix=".wav", prefix="jarvis3_")
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(wav)
                _winsound.PlaySound(path, _winsound.SND_FILENAME)
            finally:
                try:
                    os.remove(path)
                except OSError:
                    pass
            return True
        except Exception:
            return False

    def _speak_sapi(self, text):
        if sys.platform != "win32":
            return False
        safe = text.replace("'", "''").replace("\r", " ").replace("\n", " ")
        script = ("Add-Type -AssemblyName System.Speech; "
                  "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                  "try { $s.SelectVoice('Microsoft Haruka Desktop') } catch { "
                  "  try { $s.SelectVoice('Microsoft Haruka') } catch {} }; "
                  "$s.Speak('" + safe + "')")
        try:
            with self._lock:
                self._sapi_proc = hidden_popen(
                    ["powershell", "-NoProfile", "-NonInteractive",
                     "-WindowStyle", "Hidden", "-Command", script],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                proc = self._sapi_proc
            proc.wait(timeout=120)
            return True
        except Exception:
            return False


# ===========================================================================
# 聞き耳（Vosk。v2 継承）
# ===========================================================================

class VoiceListener:
    def __init__(self, model_dir, machine, on_event):
        self.model_dir = model_dir
        self.machine = machine
        self.on_event = on_event
        self._thread = None
        self._stop = threading.Event()
        self._oneshot = threading.Event()
        self.available = VOICE_INPUT_AVAILABLE and os.path.isdir(model_dir)
        self.last_error = ""

    def start(self):
        if not self.available:
            return False
        if self._thread is not None and self._thread.is_alive():
            return True
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        self._stop.set()

    def is_running(self):
        return self._thread is not None and self._thread.is_alive()

    def request_oneshot(self):
        self._oneshot.set()

    def _emit(self, kind, payload=None):
        try:
            self.on_event(kind, payload)
        except Exception:
            pass

    def _make_recognizer(self, model, quiet):
        rec = _vosk.KaldiRecognizer(model, 16000)
        if quiet:
            grammar = json.dumps(list(RESUME_PHRASES) + ["[unk]"], ensure_ascii=False)
            try:
                rec.SetGrammar(grammar)
            except Exception:
                pass
        return rec

    def _run(self):
        try:
            _vosk.SetLogLevel(-1)
            model = _vosk.Model(self.model_dir)
        except Exception as e:
            self.last_error = str(e)
            self.available = False
            return
        quiet_now = self.machine.mode == ListenStateMachine.QUIET
        rec = self._make_recognizer(model, quiet_now)
        try:
            stream = _sd.RawInputStream(samplerate=16000, blocksize=8000, dtype="int16", channels=1)
            stream.start()
        except Exception as e:
            self.last_error = str(e)
            self.available = False
            return
        try:
            while not self._stop.is_set():
                try:
                    data, _overflow = stream.read(4000)
                except Exception:
                    time.sleep(0.05)
                    continue
                want_quiet = self.machine.mode == ListenStateMachine.QUIET
                if want_quiet != quiet_now:
                    quiet_now = want_quiet
                    rec = self._make_recognizer(model, quiet_now)
                if not rec.AcceptWaveform(bytes(data)):
                    continue
                try:
                    result = json.loads(rec.Result())
                except ValueError:
                    continue
                text = (result.get("text") or "").strip()
                if not text:
                    continue
                if self._oneshot.is_set():
                    self._oneshot.clear()
                    if self.machine.mode == ListenStateMachine.QUIET:
                        self.machine.full_start()
                    self._emit("message", _strip_wake_prefix(text) or text)
                    continue
                act = self.machine.feed(text)
                kind = act.get("action")
                if kind == "message":
                    self._emit("message", act.get("text", ""))
                elif kind in ("stop_task", "quiet", "resume"):
                    self._emit(kind)
        except Exception as e:
            self.last_error = str(e)
        finally:
            try:
                stream.stop()
                stream.close()
            except Exception:
                pass


# ===========================================================================
# PC操作（v2 継承・要点。Windows のみ実動作）
# ===========================================================================

def screen_size():
    if sys.platform == "win32":
        import ctypes
        u = ctypes.windll.user32
        return u.GetSystemMetrics(0), u.GetSystemMetrics(1)
    return 1920, 1080


def _pct_to_px(x_pct, y_pct):
    w, h = screen_size()
    return int(w * x_pct / 100.0), int(h * y_pct / 100.0)


def pc_click(x_pct, y_pct, button="left", double=False):
    if sys.platform != "win32":
        return False
    import ctypes
    u = ctypes.windll.user32
    x, y = _pct_to_px(x_pct, y_pct)
    u.SetCursorPos(x, y)
    flags = {"left": (0x0002, 0x0004), "right": (0x0008, 0x0010)}.get(button, (0x0002, 0x0004))
    u.mouse_event(flags[0], 0, 0, 0, 0)
    u.mouse_event(flags[1], 0, 0, 0, 0)
    if double:
        u.mouse_event(flags[0], 0, 0, 0, 0)
        u.mouse_event(flags[1], 0, 0, 0, 0)
    return True


def pc_key(vk_list):
    if sys.platform != "win32" or not vk_list:
        return False
    import ctypes
    u = ctypes.windll.user32
    for vk in vk_list:
        u.keybd_event(vk, 0, 0, 0)
    for vk in reversed(vk_list):
        u.keybd_event(vk, 0, 0x0002, 0)
    return True


def set_clipboard_text(text):
    if sys.platform != "win32":
        return False
    try:
        env = dict(os.environ)
        env["JARVIS3_CLIP"] = text or ""
        run_hidden(["powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
                    "-Command", "Set-Clipboard -Value $env:JARVIS3_CLIP"],
                   env=env, timeout=15)
        return True
    except Exception:
        return False


def pc_type_text(text):
    if not set_clipboard_text(text):
        return False
    vks = key_spec_to_vk("ctrl+v")
    return pc_key(vks) if vks else False


def execute_action(action, cfg, confirm_fn=None):
    """parse_action の結果を実行する。ガード対象は confirm_fn で確認してから。"""
    confirm_fn = confirm_fn or (lambda msg: False)
    t = action.get("type")
    if t == "text":
        return action.get("text", "")
    if t in ("create_file", "edit_file"):
        if needs_shopping_confirm(action.get("name", "")) or needs_destructive_confirm(action.get("name", "")):
            if not confirm_fn("ファイル作成を確認してください: %s" % action.get("name")):
                return "確認で止めました"
        dest = safe_join(WORKSPACE_DIR, action.get("name", "無題.txt"))
        if dest is None:
            return "安全のため書き込めませんでした"
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "w", encoding="utf-8") as f:
            f.write(action.get("body", ""))
        ok, msg = verify_created_file(dest)
        return "作りました: %s（検証: %s）" % (action.get("name"), msg)
    if t == "command":
        cmd = action.get("cmd", "")
        if needs_shopping_confirm(cmd) or needs_destructive_confirm(cmd):
            if not confirm_fn("コマンドを確認してください: %s" % cmd):
                return "確認で止めました"
        try:
            r = run_hidden(cmd, shell=True, capture_output=True, timeout=120)
            return _decode(r.stdout)[:2000] or "実行しました"
        except Exception as e:
            return "コマンド失敗: %s" % e
    if t in ("click", "double_click", "right_click"):
        btn = "right" if t == "right_click" else "left"
        pc_click(action.get("x", 0), action.get("y", 0), btn, t == "double_click")
        return "クリックしました"
    if t == "key":
        vks = key_spec_to_vk(action.get("spec", ""))
        return "キーを押しました" if (vks and pc_key(vks)) else "キーを解釈できませんでした"
    if t == "type_text":
        return "入力しました" if pc_type_text(action.get("text", "")) else "入力できませんでした"
    if t == "app":
        target = action.get("target", "")
        if needs_destructive_confirm(target):
            if not confirm_fn("アプリ起動を確認してください: %s" % target):
                return "確認で止めました"
        try:
            hidden_popen([target], hide_window=False)
            return "開きました: %s" % target
        except Exception as e:
            return "開けませんでした: %s" % e
    if t == "done":
        return action.get("summary", "")
    return "対応しました（%s）" % t


# ===========================================================================
# GUI（tkinter）: オーブ常駐 + メイン窓タブ [会話][性格][自分コピー][作る][設定]
# ===========================================================================

class JarvisApp:
    def __init__(self, root):
        self.root = root
        ensure_data_dirs()
        prepare_bundled_resources()
        self.cfg = load_config()
        self.store = PersonalityStore()
        self.memory = MemoryDB()
        self.self_profile = load_self_profile()
        self.brake = FailureBrake(threshold=5)
        self.server = LlamaServer(self.cfg)
        self.client = LlamaClient(self.cfg)
        self.voice = VoiceEngine(int(self.cfg.get("speaker_id", 11)))
        self.machine = ListenStateMachine()
        self.listener = VoiceListener(VOSK_MODEL_DIR, self.machine, self._on_voice_event)
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.persona = self.store.get(self.cfg.get("persona_id") or "") or self._default_persona()
        self._build_orb()
        self._build_main_window()
        self.root.after(150, self._poll_events)
        log_line("JarvisPC3 起動")
        if self.cfg.get("listen_on", True):
            self.listener.start()

    def _default_persona(self):
        ps = self.store.list_all()
        if ps:
            return ps[0]
        p = self.store.create("ジャービス")
        p["profile"] = fallback_profile("ジャービス", "", "")
        p["system_prompt"] = build_persona_section(p)
        self.store.save(p)
        return p

    def _build_orb(self):
        self.orb = tk.Toplevel(self.root)
        self.orb.overrideredirect(True)
        self.orb.attributes("-topmost", True)
        try:
            self.orb.attributes("-alpha", 0.92)
        except Exception:
            pass
        w, h = 110, 110
        sw = self.orb.winfo_screenwidth()
        self.orb.geometry("%dx%d+%d+%d" % (w, h, sw - w - 24, 120))
        self.canvas = tk.Canvas(self.orb, width=w, height=h, bg="#10131c", highlightthickness=0)
        self.canvas.pack()
        self._orb_phase = 0
        self._draw_orb()
        self.canvas.bind("<Button-1>", lambda e: self._toggle_main())
        self.canvas.bind("<Button-3>", lambda e: self._orb_menu(e))
        self._animate_orb()

    def _draw_orb(self):
        c = self.canvas
        c.delete("all")
        state = self.machine.state()
        color = {"LISTENING": "#57b6ff", "QUIET": "#8a8f9c",
                 "FULL_OFF": "#555a66", "SPEAKING_MUTED": "#ffd257"}.get(state, "#57b6ff")
        r = 34 + (3 if self._orb_phase % 2 == 0 else 0)
        c.create_oval(55 - r, 55 - r, 55 + r, 55 + r, outline=color, width=3)
        c.create_oval(55 - 10, 55 - 10, 55 + 10, 55 + 10, fill=color, outline="")
        c.create_text(55, 100, text="ジャービス", fill="#cfe3ff", font=("Meiryo UI", 8))

    def _animate_orb(self):
        self._orb_phase += 1
        try:
            self._draw_orb()
        except Exception:
            pass
        self.root.after(900, self._animate_orb)

    def _orb_menu(self, event):
        menu = tk.Menu(self.orb, tearoff=0)
        menu.add_command(label="窓を開く/閉じる", command=self._toggle_main)
        menu.add_command(label="聞き耳を止める（完全）", command=self._full_stop)
        menu.add_command(label="聞き耳を始める", command=self._full_start)
        menu.add_command(label="読み上げを止める", command=self.voice.stop)
        menu.add_separator()
        menu.add_command(label="終了", command=self._quit)
        menu.tk_popup(event.x_root, event.y_root)

    def _full_stop(self):
        self.machine.full_stop()
        log_line("聞き耳 完全停止")

    def _full_start(self):
        self.machine.full_start()
        self.listener.start()

    def _toggle_main(self):
        if self.main.state() == "withdrawn":
            self.main.deiconify()
            self.main.lift()
        else:
            self.main.withdraw()

    def _quit(self):
        try:
            self.listener.stop()
            self.voice.stop()
            self.server.stop()
        except Exception:
            pass
        self.root.destroy()

    def _build_main_window(self):
        self.main = tk.Toplevel(self.root)
        self.main.title("ジャービスPC v3.1（JarvisNEO）")
        self.main.geometry("980x720")
        self.main.protocol("WM_DELETE_WINDOW", lambda: self.main.withdraw())
        nb = ttk.Notebook(self.main)
        nb.pack(fill="both", expand=True)
        self.tab_chat = ttk.Frame(nb)
        self.tab_persona = ttk.Frame(nb)
        self.tab_self = ttk.Frame(nb)
        self.tab_maker = ttk.Frame(nb)
        self.tab_settings = ttk.Frame(nb)
        nb.add(self.tab_chat, text="会話")
        nb.add(self.tab_persona, text="性格")
        nb.add(self.tab_self, text="自分コピー")
        nb.add(self.tab_maker, text="作る")
        nb.add(self.tab_settings, text="設定（全カスタム）")
        self._build_chat_tab()
        self._build_persona_tab()
        self._build_self_tab()
        self._build_maker_tab()
        self._build_settings_tab()
        self.status_var = tk.StringVar(value="準備中… モデルは設定タブで選べます")
        tk.Label(self.main, textvariable=self.status_var, anchor="w").pack(fill="x")
        self.main.withdraw()

    def _build_chat_tab(self):
        f = self.tab_chat
        self.chat_view = scrolledtext.ScrolledText(f, wrap="word", font=("Meiryo UI", 11))
        self.chat_view.pack(fill="both", expand=True, padx=6, pady=6)
        row = ttk.Frame(f)
        row.pack(fill="x", padx=6, pady=4)
        self.input_box = tk.Text(row, height=3, font=("Meiryo UI", 11))
        self.input_box.pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="送信", command=self._send_from_gui).pack(side="left", padx=4)
        ttk.Button(row, text="止める", command=lambda: self.stop_event.set()).pack(side="left")
        ttk.Button(row, text="マイクで1回", command=self.listener.request_oneshot).pack(side="left", padx=4)
        row2 = ttk.Frame(f)
        row2.pack(fill="x", padx=6)
        tk.Label(row2, text="ずっと覚えるメモ:").pack(side="left")
        self.facts_box = tk.Text(row2, height=2, font=("Meiryo UI", 10))
        self.facts_box.pack(side="left", fill="x", expand=True)
        self.facts_box.insert("1.0", load_facts())
        ttk.Button(row2, text="メモ保存", command=self._save_facts).pack(side="left", padx=4)

    def _save_facts(self):
        save_facts(self.facts_box.get("1.0", "end").strip())
        self._set_status("ずっと覚えるメモを保存しました")

    def _append_chat(self, who, text):
        self.chat_view.insert("end", "%s: %s\n\n" % (who, text))
        self.chat_view.see("end")

    def _send_from_gui(self):
        text = self.input_box.get("1.0", "end").strip()
        if not text:
            return
        self.input_box.delete("1.0", "end")
        self._handle_user_text(text)

    def _handle_user_text(self, text):
        self._append_chat(self.cfg.get("user_name", "鳥"), text)
        self.stop_event = threading.Event()
        threading.Thread(target=self._chat_worker, args=(text,), daemon=True).start()

    def _ensure_model(self):
        if self.server.healthy():
            return True
        mp = detect_model(self.cfg)
        return self.server.start(mp, lambda st, msg: self.events.put(("status", msg)))

    def _chat_worker(self, text):
        try:
            if not self._ensure_model():
                self.events.put(("chat", "モデルを起動できませんでした。設定タブでGGUFモデルを選んでください。"))
                return
            self.client = LlamaClient(effective_config(self.cfg, self.persona))
            reply, sources = chat_once(self.memory, self.cfg, self.persona,
                                       self.self_profile, text, self.client)
            self.brake.record_success("chat")
            if sources:
                src = "\n".join("[出典] %s %s" % (s["title"], s["url"]) for s in sources)
                self.events.put(("chat_src", src))
            self.events.put(("chat", reply or "（返事なし）"))
            act = parse_action(reply or "")
            if self.cfg.get("agent_on") and act.get("type") not in ("text", None):
                if needs_shopping_confirm(str(act)) or needs_destructive_confirm(str(act)):
                    self.events.put(("confirm_action", act))
                else:
                    result = execute_action(act, self.cfg)
                    self.events.put(("chat", result))
            if self.cfg.get("voice_on", True):
                speech = sanitize_for_speech(reply or "")
                if speech:
                    self.machine.set_speaking(True)
                    self.voice.speak_async(speech, on_done=lambda ok: self._speech_done())
        except Exception as e:
            tripped = self.brake.record_failure("chat")
            log_line("会話エラー: %s (brake=%s)" % (e, tripped))
            self.events.put(("chat", "エラーが出ました: %s" % e))

    def _speech_done(self):
        self.machine.set_speaking(False)

    def _on_voice_event(self, kind, payload=None):
        self.events.put(("voice_" + kind, payload))

    def _build_persona_tab(self):
        f = self.tab_persona
        top = ttk.Frame(f)
        top.pack(fill="x", padx=6, pady=6)
        tk.Label(top, text="新しい性格の言葉:").pack(side="left")
        self.persona_word = tk.Entry(top, width=28)
        self.persona_word.pack(side="left", padx=4)
        tk.Label(top, text="希望メモ:").pack(side="left")
        self.persona_memo = tk.Entry(top, width=24)
        self.persona_memo.pack(side="left", padx=4)
        ttk.Button(top, text="性格を作る（調査+カード生成）", command=self._create_persona).pack(side="left")
        mid = ttk.Frame(f)
        mid.pack(fill="x", padx=6)
        self.persona_list = tk.Listbox(mid, height=6)
        self.persona_list.pack(side="left", fill="x", expand=True)
        self.persona_list.bind("<<ListboxSelect>>", lambda e: self._select_persona())
        btns = ttk.Frame(mid)
        btns.pack(side="left", padx=4)
        ttk.Button(btns, text="この性格にする", command=self._apply_persona).pack(fill="x", pady=2)
        ttk.Button(btns, text="削除", command=self._delete_persona).pack(fill="x", pady=2)
        tk.Label(f, text="性格カード（8項目・直接編集できます）:").pack(anchor="w", padx=6)
        self.persona_fields = {}
        grid = ttk.Frame(f)
        grid.pack(fill="both", expand=True, padx=6)
        for i, (key, label) in enumerate(PROFILE_FIELDS):
            tk.Label(grid, text=label, width=26, anchor="w").grid(row=i, column=0, sticky="nw", pady=1)
            t = tk.Text(grid, height=2, wrap="word", font=("Meiryo UI", 10))
            t.grid(row=i, column=1, sticky="ew", pady=1)
            grid.columnconfigure(1, weight=1)
            self.persona_fields[key] = t
        btm = ttk.Frame(f)
        btm.pack(fill="x", padx=6, pady=4)
        tk.Label(btm, text="適用の強さ:").pack(side="left")
        self.strength_var = tk.StringVar(value=str(self.cfg.get("persona_strength", "max")))
        for v in ("normal", "strong", "max"):
            tk.Radiobutton(btm, text=v, variable=self.strength_var, value=v).pack(side="left")
        ttk.Button(btm, text="カードを保存", command=self._save_persona_card).pack(side="left", padx=8)
        self._refresh_persona_list()

    def _refresh_persona_list(self):
        self.persona_list.delete(0, "end")
        self._persona_ids = []
        for p in self.store.list_all():
            mark = "（仮）" if p.get("profile_source") == "fallback" else ""
            self.persona_list.insert("end", "%s%s" % (p.get("display_name") or p.get("input_word"), mark))
            self._persona_ids.append(p["id"])

    def _selected_persona_id(self):
        sel = self.persona_list.curselection()
        if not sel:
            return None
        return self._persona_ids[sel[0]]

    def _select_persona(self):
        pid = self._selected_persona_id()
        p = self.store.get(pid) if pid else None
        if not p:
            return
        for key, _label in PROFILE_FIELDS:
            self.persona_fields[key].delete("1.0", "end")
            self.persona_fields[key].insert("1.0", (p.get("profile") or {}).get(key, ""))

    def _apply_persona(self):
        pid = self._selected_persona_id()
        p = self.store.get(pid) if pid else None
        if p:
            self.persona = p
            self.cfg["persona_id"] = p["id"]
            self.cfg["persona_strength"] = self.strength_var.get()
            save_config(CONFIG_PATH, self.cfg)
            self._set_status("性格を「%s」にしました（強さ: %s）" % (p.get("display_name"), self.strength_var.get()))

    def _delete_persona(self):
        pid = self._selected_persona_id()
        if pid and messagebox.askyesno("確認", "この性格を消しますか？"):
            self.store.delete(pid)
            self._refresh_persona_list()

    def _save_persona_card(self):
        pid = self._selected_persona_id() or (self.persona or {}).get("id")
        p = self.store.get(pid) if pid else None
        if not p:
            return
        for key, _label in PROFILE_FIELDS:
            p.setdefault("profile", {})[key] = self.persona_fields[key].get("1.0", "end").strip()
        p["profile_source"] = "manual"
        p["system_prompt"] = build_persona_section(p)
        self.store.save(p)
        if self.persona and self.persona.get("id") == p["id"]:
            self.persona = p
        self._set_status("性格カードを保存しました")

    def _create_persona(self):
        word = self.persona_word.get().strip()
        if not word:
            messagebox.showinfo("ジャービス", "性格の言葉を入れてください")
            return
        memo = self.persona_memo.get().strip()
        p = self.store.create(word, memo=memo)
        self._refresh_persona_list()
        threading.Thread(target=self._persona_worker, args=(p,), daemon=True).start()

    def _persona_worker(self, p):
        try:
            if not self._ensure_model():
                self.events.put(("status", "モデル未起動のため仮カードで作ります"))
                client = None
            else:
                client = LlamaClient(effective_config(self.cfg, p))
            p, _used = research_and_build_personality(
                self.store, p, client, self.cfg,
                lambda m: self.events.put(("status", m)))
            self.events.put(("persona_done", p["id"]))
        except Exception as e:
            log_line("性格作成エラー: %s" % e)
            self.events.put(("status", "性格作成でエラー: %s" % e))

    def _build_self_tab(self):
        f = self.tab_self
        top = ttk.Frame(f)
        top.pack(fill="x", padx=6, pady=6)
        ttk.Button(top, text="特徴ファイルを入れる（複数可・.txt/.md/.json/.csv）",
                   command=self._import_self_file).pack(side="left")
        ttk.Button(top, text="フォルダごと取り込む",
                   command=self._import_self_folder).pack(side="left", padx=4)
        ttk.Button(top, text="直接入力を振り分けて足す",
                   command=self._import_self_text).pack(side="left", padx=4)
        self.copy_var = tk.BooleanVar(value=bool(self.cfg.get("copy_mode", False)))
        tk.Checkbutton(top, text="自分コピーモード（鳥の分身として答える）",
                       variable=self.copy_var, command=self._toggle_copy_mode).pack(side="left", padx=8)
        tk.Label(f, text="直接入力（文章で書けば自動で項目に分かれます）:").pack(anchor="w", padx=6)
        self.self_input = tk.Text(f, height=4, wrap="word", font=("Meiryo UI", 10))
        self.self_input.pack(fill="x", padx=6)
        tk.Label(f, text="項目別（8項目・直接直せます。性格とは別枠で保存されます）:").pack(anchor="w", padx=6, pady=(6, 0))
        self.self_fields = {}
        grid = ttk.Frame(f)
        grid.pack(fill="both", expand=True, padx=6)
        for i, (key, label) in enumerate(SELF_FIELDS):
            tk.Label(grid, text=label, width=18, anchor="w").grid(row=i, column=0, sticky="nw", pady=1)
            t = tk.Text(grid, height=2, wrap="word", font=("Meiryo UI", 10))
            t.grid(row=i, column=1, sticky="ew", pady=1)
            grid.columnconfigure(1, weight=1)
            self.self_fields[key] = t
        ttk.Button(f, text="自分コピーを保存", command=self._save_self_fields).pack(pady=4)
        self._refresh_self_fields()

    def _refresh_self_fields(self):
        for key, _label in SELF_FIELDS:
            self.self_fields[key].delete("1.0", "end")
            self.self_fields[key].insert("1.0", self.self_profile.get(key, ""))

    def _toggle_copy_mode(self):
        self.cfg["copy_mode"] = bool(self.copy_var.get())
        save_config(CONFIG_PATH, self.cfg)
        self._set_status("自分コピーモード: %s" % ("ON" if self.cfg["copy_mode"] else "OFF"))

    def _import_self_paths(self, paths):
        """選んだファイルを全部、順に取り込む（1つ失敗しても残りは続ける）。"""
        ok = 0
        for path in paths:
            try:
                prof, raw = import_self_profile_file(path)
                self.self_profile = merge_self_profile(self.self_profile, prof)
                save_self_profile(self.self_profile, raw_text=raw,
                                  raw_filename=os.path.basename(path))
                ok += 1
            except Exception as e:
                messagebox.showerror("ジャービス", "取り込み失敗（%s）: %s"
                                     % (os.path.basename(path), e))
        if ok:
            self._refresh_self_fields()
            self._set_status("%d件の特徴ファイルを取り込みました（8項目に振り分け・原文は全文保存済み）" % ok)
        return ok

    def _import_self_file(self):
        paths = filedialog.askopenfilenames(
            title="自分の特徴ファイル（複数選べます）",
            filetypes=[("テキスト/マークダウン/JSON/CSV", "*.txt *.md *.json *.csv"),
                       ("すべて", "*.*")])
        if not paths:
            return
        self._import_self_paths(list(paths))

    def _import_self_folder(self):
        folder = filedialog.askdirectory(title="特徴ファイルが入ったフォルダ")
        if not folder:
            return
        try:
            names = sorted(os.listdir(folder))
        except Exception as e:
            messagebox.showerror("ジャービス", "フォルダを開けませんでした: %s" % e)
            return
        paths = [os.path.join(folder, n) for n in names
                 if os.path.splitext(n)[1].lower() in (".txt", ".md", ".json", ".csv")
                 and os.path.isfile(os.path.join(folder, n))]
        if not paths:
            self._set_status("そのフォルダに取り込めるファイル（.txt/.md/.json/.csv）がありませんでした")
            return
        self._import_self_paths(paths)

    def _import_self_text(self):
        text = self.self_input.get("1.0", "end").strip()
        if not text:
            return
        prof = parse_self_profile(text)
        self.self_profile = merge_self_profile(self.self_profile, prof)
        try:
            append_self_chunks("direct_input.txt", text)
        except Exception:
            pass
        save_self_profile(self.self_profile, raw_text=text, raw_filename="direct_input.txt")
        self.self_input.delete("1.0", "end")
        self._refresh_self_fields()
        self._set_status("直接入力を振り分けて足しました")

    def _save_self_fields(self):
        for key, _label in SELF_FIELDS:
            self.self_profile[key] = self.self_fields[key].get("1.0", "end").strip()
        save_self_profile(self.self_profile)
        self._set_status("自分コピーを保存しました（性格とは別に保存されています）")

    def _build_maker_tab(self):
        f = self.tab_maker
        tk.Label(f, text="作りたい物を書いてください。要素リスト→生成→自動検証→最大3回まで自動修正→照合レポートまで進みます。").pack(anchor="w", padx=6, pady=4)
        self.maker_input = tk.Text(f, height=4, wrap="word", font=("Meiryo UI", 11))
        self.maker_input.pack(fill="x", padx=6)
        row = ttk.Frame(f)
        row.pack(fill="x", padx=6, pady=4)
        ttk.Button(row, text="作る", command=self._run_maker).pack(side="left")
        tk.Label(row, text="保存先: workspace フォルダ（%s）" % WORKSPACE_DIR).pack(side="left", padx=6)
        self.maker_view = scrolledtext.ScrolledText(f, wrap="word", font=("Meiryo UI", 10))
        self.maker_view.pack(fill="both", expand=True, padx=6, pady=4)

    def _run_maker(self):
        req = self.maker_input.get("1.0", "end").strip()
        if not req:
            return
        threading.Thread(target=self._maker_worker, args=(req,), daemon=True).start()

    def _maker_worker(self, req):
        try:
            if not self._ensure_model():
                self.events.put(("maker", "モデルを起動できませんでした。設定タブでモデルを選んでください。"))
                return
            client = LlamaClient(effective_config(self.cfg, self.persona))
            system = build_full_system_prompt(self.persona, self.self_profile,
                                              bool(self.cfg.get("copy_mode")), self.cfg)
            report, _results = maker_loop(
                client, system, req, WORKSPACE_DIR, self.cfg,
                on_step=lambda m: self.events.put(("maker_step", m)))
            self.events.put(("maker", report))
            log_line("作る力 完了: %s" % req[:60])
        except Exception as e:
            self.brake.record_failure("maker")
            log_line("作る力エラー: %s" % e)
            self.events.put(("maker", "エラーが出ました: %s" % e))

    def _build_settings_tab(self):
        f = self.tab_settings
        canvas = tk.Canvas(f)
        sb = ttk.Scrollbar(f, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.setting_vars = {}
        for i, (key, label, typ) in enumerate(SETTINGS_SCHEMA):
            tk.Label(inner, text=label, width=52, anchor="w").grid(row=i, column=0, sticky="w", pady=1)
            if typ == "bool":
                var = tk.BooleanVar(value=bool(self.cfg.get(key, DEFAULT_CONFIG.get(key, False))))
                tk.Checkbutton(inner, variable=var).grid(row=i, column=1, sticky="w")
            else:
                var = tk.StringVar(value=str(self.cfg.get(key, DEFAULT_CONFIG.get(key, ""))))
                tk.Entry(inner, textvariable=var, width=64).grid(row=i, column=1, sticky="w")
            self.setting_vars[key] = (var, typ)
        row = ttk.Frame(inner)
        row.grid(row=len(SETTINGS_SCHEMA) + 1, column=0, columnspan=2, pady=8)
        ttk.Button(row, text="モデルを選ぶ", command=self._pick_model).pack(side="left")
        ttk.Button(row, text="mmprojを選ぶ", command=self._pick_mmproj).pack(side="left", padx=4)
        ttk.Button(row, text="設定を保存", command=self._save_settings).pack(side="left", padx=4)
        ttk.Button(row, text="モデルを起動", command=lambda: threading.Thread(target=self._ensure_model, daemon=True).start()).pack(side="left")

    def _pick_model(self):
        path = filedialog.askopenfilename(title="GGUFモデル", filetypes=[("GGUF", "*.gguf"), ("すべて", "*.*")])
        if path:
            var, _t = self.setting_vars["model_path"]
            var.set(path)

    def _pick_mmproj(self):
        path = filedialog.askopenfilename(title="mmproj GGUF", filetypes=[("GGUF", "*.gguf"), ("すべて", "*.*")])
        if path:
            var, _t = self.setting_vars["mmproj_path"]
            var.set(path)

    def _save_settings(self):
        for key, (var, typ) in self.setting_vars.items():
            try:
                if typ == "bool":
                    self.cfg[key] = bool(var.get())
                elif typ == "int":
                    self.cfg[key] = int(float(var.get()))
                elif typ == "float":
                    self.cfg[key] = float(var.get())
                else:
                    self.cfg[key] = var.get()
            except (TypeError, ValueError):
                pass
        self.cfg["persona_strength"] = str(self.cfg.get("persona_strength", "max")).lower()
        if self.cfg["persona_strength"] not in ("normal", "strong", "max"):
            self.cfg["persona_strength"] = "max"
        self.cfg["maker_max_retries"] = max(0, min(int(self.cfg.get("maker_max_retries", 3)), MAKER_MAX_RETRIES))
        save_config(CONFIG_PATH, self.cfg)
        self.server.cfg = self.cfg
        self._set_status("設定を保存しました（モデルの変更は次回起動時に反映）")

    def _set_status(self, msg):
        self.status_var.set(msg)
        log_line(msg)

    def _poll_events(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "status":
                    self._set_status(str(payload))
                elif kind == "chat":
                    self._append_chat("ジャービス", str(payload))
                elif kind == "chat_src":
                    self.chat_view.insert("end", str(payload) + "\n")
                    self.chat_view.see("end")
                elif kind in ("maker", "maker_step"):
                    self.maker_view.insert("end", str(payload) + "\n")
                    self.maker_view.see("end")
                elif kind == "persona_done":
                    self._refresh_persona_list()
                    self._set_status("性格ができました")
                elif kind == "voice_message":
                    self._handle_user_text(str(payload))
                elif kind == "voice_quiet":
                    self._set_status("静かモードになりました（「聞いて」で再開）")
                elif kind == "voice_resume":
                    self._set_status("聞き耳を再開しました")
                elif kind == "confirm_action":
                    act = payload
                    if messagebox.askyesno("確認", "買い物・破壊的な操作の可能性があります。実行しますか？\n%s" % act):
                        result = execute_action(act, self.cfg, confirm_fn=lambda m: True)
                        self._append_chat("ジャービス", result)
        except queue.Empty:
            pass
        self.root.after(150, self._poll_events)


def run_gui():
    if tk is None:
        raise RuntimeError("tkinter が使えない環境です")
    root = tk.Tk()
    root.withdraw()
    app = JarvisApp(root)
    root.mainloop()
    return app


if __name__ == "__main__":
    run_gui()
