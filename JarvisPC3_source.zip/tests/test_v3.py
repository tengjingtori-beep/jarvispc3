# -*- coding: utf-8 -*-
import json
import os
import sys
import tempfile
import unittest

_here = os.path.dirname(__file__)
sys.path.insert(0, os.path.abspath(os.path.join(_here, "..", "app")))
import jarvis3 as j


class TestSelfProfile(unittest.TestCase):
    def test_never_drops_sentences(self):
        text = ("名前は鳥です。好きな食べ物はプリンです。"
                "全然関係ない不思議な文がここにあります。"
                "いつも朝は早く起きます。")
        prof = j.parse_self_profile(text)
        joined = "\n".join(prof.values())
        for sent in ("名前は鳥です", "好きな食べ物はプリンです",
                     "全然関係ない不思議な文がここにあります", "いつも朝は早く起きます"):
            self.assertIn(sent, joined)

    def test_heading_split(self):
        text = "# 話し方\n一人称は僕です。\n# 好き嫌い\nプリンが好きです。\n"
        prof = j.parse_self_profile(text)
        self.assertIn("一人称は僕です", prof["speech"])
        self.assertIn("プリンが好きです", prof["likes_dislikes"])

    def test_keyword_split(self):
        prof = j.parse_self_profile("口癖は「まあいいか」です。毎日ジョギングをします。")
        self.assertIn("口癖", prof["speech"])
        # 「毎日」→ 習慣キーワード
        prof2 = j.parse_self_profile("毎日ジョギングをします。")
        self.assertIn("ジョギング", prof2["habits"])

    def test_json_input(self):
        prof = j.parse_self_profile(json.dumps({"basic": "鳥です", "謎キー": "捨てない値"}, ensure_ascii=False))
        self.assertIn("鳥です", prof["basic"])
        self.assertIn("捨てない値", prof["memories"])

    def test_all_eight_fields_exist(self):
        prof = j.parse_self_profile("テストです。")
        self.assertEqual(set(prof.keys()), {k for k, _ in j.SELF_FIELDS})


class TestPersonaVsSelfSeparation(unittest.TestCase):
    def _persona(self):
        return {"id": "p1", "display_name": "ツンデレ執事", "input_word": "ツンデレ執事",
                "memo": "", "profile": {"speech": "語尾は〜だぞ", "traits": "ツンデレ"},
                "web_summary": "", "extra_prompt": ""}

    def test_both_sections_present_and_separate(self):
        prof = j.empty_self_profile()
        prof["basic"] = "鳥本人データXYZ"
        prompt = j.build_full_system_prompt(self._persona(), prof, copy_mode=False, cfg={})
        self.assertIn("ツンデレ執事", prompt)
        self.assertIn("鳥本人データXYZ", prompt)
        # 性格セクションには自分コピーの印が無く、自分コピー側にだけ印がある
        persona_sec = j.build_persona_section(self._persona())
        self.assertNotIn("自分コピー", persona_sec)
        self_sec = j.build_self_section(prof, copy_mode=False)
        self.assertIn("自分コピー", self_sec)
        self.assertNotIn("ツンデレ執事", self_sec)

    def test_copy_mode_strengthens(self):
        prof = j.empty_self_profile()
        prof["speech"] = "一人称は僕"
        off = j.build_self_section(prof, copy_mode=False)
        on = j.build_self_section(prof, copy_mode=True)
        self.assertNotIn("自分コピーモードON", off)
        self.assertIn("自分コピーモードON", on)
        self.assertIn("鳥の分身", on)
        self.assertGreater(len(on), len(off))

    def test_empty_self_gives_no_section(self):
        self.assertEqual(j.build_self_section(j.empty_self_profile()), "")


class TestMaker(unittest.TestCase):
    def test_parse_plan(self):
        text = ("要素:\n- 計算ができる\n- ボタンがある\n"
                "ファイル: calc.py\n```python\nprint(1+1)\n```\n")
        plan = j.parse_maker_plan(text)
        self.assertEqual(plan["elements"], ["計算ができる", "ボタンがある"])
        self.assertEqual(len(plan["files"]), 1)
        self.assertEqual(plan["files"][0]["name"], "calc.py")
        self.assertIn("print(1+1)", plan["files"][0]["body"])

    def test_verify_py_ok_and_ng(self):
        with tempfile.TemporaryDirectory() as d:
            good = os.path.join(d, "a.py")
            with open(good, "w", encoding="utf-8") as f:
                f.write("x = 1\nprint(x)\n")
            ok, _msg = j.verify_created_file(good)
            self.assertTrue(ok)
            bad = os.path.join(d, "b.py")
            with open(bad, "w", encoding="utf-8") as f:
                f.write("def broken(:\n")
            ok, _msg = j.verify_created_file(bad)
            self.assertFalse(ok)

    def test_verify_json_ok_and_ng(self):
        with tempfile.TemporaryDirectory() as d:
            good = os.path.join(d, "a.json")
            with open(good, "w", encoding="utf-8") as f:
                f.write('{"a": 1}')
            self.assertTrue(j.verify_created_file(good)[0])
            bad = os.path.join(d, "b.json")
            with open(bad, "w", encoding="utf-8") as f:
                f.write("{壊れた")
            self.assertFalse(j.verify_created_file(bad)[0])

    def test_verify_html_ok_and_ng(self):
        with tempfile.TemporaryDirectory() as d:
            good = os.path.join(d, "a.html")
            with open(good, "w", encoding="utf-8") as f:
                f.write("<html><body><p>やあ</p><br></body></html>")
            self.assertTrue(j.verify_created_file(good)[0])
            bad = os.path.join(d, "b.html")
            with open(bad, "w", encoding="utf-8") as f:
                f.write("<html><body><p>閉じてない")
            self.assertFalse(j.verify_created_file(bad)[0])
            empty = os.path.join(d, "c.txt")
            with open(empty, "w", encoding="utf-8") as f:
                f.write("   ")
            self.assertFalse(j.verify_created_file(empty)[0])

    def test_maker_loop_retries_and_succeeds(self):
        calls = {"n": 0}

        def gen(system, prompt):
            calls["n"] += 1
            if "エラー" in prompt:  # 修正依頼には正しいコードを返す
                return "ファイル: a.py\n```\nprint('ok')\n```\n"
            return ("要素:\n- 挨拶する\nファイル: a.py\n```\ndef broken(:\n```\n")

        with tempfile.TemporaryDirectory() as d:
            report, results = j.maker_loop(None, "sys", "挨拶プログラム", d,
                                           cfg={}, generate_fn=gen)
            self.assertTrue(results[0]["ok"])
            self.assertIn("挨拶する", report)
            self.assertGreaterEqual(calls["n"], 2)

    def test_maker_max_retries_constant(self):
        self.assertEqual(j.MAKER_MAX_RETRIES, 3)


class TestPureLogicV2(unittest.TestCase):
    def test_strip_think(self):
        self.assertEqual(j.strip_think("<think>考え中</think>答え"), "答え")
        self.assertEqual(j.strip_think("<think>閉じてない"), "")
        self.assertEqual(j.strip_think("普通の文"), "普通の文")

    def test_sanitize_for_speech(self):
        out = j.sanitize_for_speech("クリック: 50 50\nこんにちは。元気ですか？")
        self.assertNotIn("クリック", out)
        self.assertIn("こんにちは", out)
        self.assertEqual(j.sanitize_for_speech("```code```"), "")
        out2 = j.sanitize_for_speech("詳しくは https://example.com を見てね。")
        self.assertNotIn("http", out2)

    def test_parse_action(self):
        a = j.parse_action("クリック: 10 20")
        self.assertEqual(a["type"], "click")
        self.assertEqual((a["x"], a["y"]), (10.0, 20.0))
        a = j.parse_action("キー: ctrl+c")
        self.assertEqual(a["type"], "key")
        self.assertEqual(a["spec"], "ctrl+c")
        a = j.parse_action("ただの返事です")
        self.assertEqual(a["type"], "text")
        a = j.parse_action("ファイル作成: memo.txt\n中身です")
        self.assertEqual(a["type"], "create_file")
        self.assertEqual(a["name"], "memo.txt")

    def test_guards(self):
        self.assertTrue(j.needs_shopping_confirm("これを購入して"))
        self.assertTrue(j.needs_shopping_confirm("please buy it"))
        self.assertFalse(j.needs_shopping_confirm("メモを作って"))
        self.assertTrue(j.needs_destructive_confirm("shutdown /s"))
        self.assertTrue(j.needs_destructive_confirm("Remove-Item -Recurse C:\\x"))
        self.assertFalse(j.needs_destructive_confirm("ファイルを開いて"))

    def test_build_sarashina_prompt(self):
        p = j.build_sarashina_prompt("SYS", [("user", "やあ"), ("assistant", "やあ！")])
        self.assertTrue(p.startswith("<|system|>SYS</s>"))
        self.assertIn("<|user|>やあ</s>", p)
        self.assertTrue(p.endswith("<|assistant|>"))

    def test_sanitize_relpath_and_safe_join(self):
        self.assertEqual(j.sanitize_relpath("../evil.txt"), "evil.txt")
        self.assertEqual(j.sanitize_relpath("a/b/c.txt"), "a/b/c.txt")
        with tempfile.TemporaryDirectory() as d:
            inside = j.safe_join(d, "sub/file.txt")
            self.assertTrue(inside.startswith(os.path.abspath(d)))
            self.assertIsNotNone(j.safe_join(d, "..\\..\\x.txt"))  # 安全化されて中に入る

    def test_parse_profile_json_rescue(self):
        raw = '前置き```json\n{"identity": "x", "traits": "y"}\n```後置き'
        prof = j.parse_profile_json(raw)
        self.assertEqual(prof["identity"], "x")
        self.assertIsNone(j.parse_profile_json("jsonじゃない"))
        broken = '{"identity": "救済テスト", "speech": "口調" 壊れた'
        prof2 = j.parse_profile_json(broken)
        self.assertIsNotNone(prof2)
        self.assertEqual(prof2["identity"], "救済テスト")

    def test_listen_state_machine(self):
        m = j.ListenStateMachine()
        r = m.feed("ジャービス、天気は？", now=100.0)
        self.assertEqual(r["action"], "message")
        r = m.feed("静かにして", now=101.0)
        self.assertEqual(r["action"], "quiet")
        r = m.feed("何か話して", now=102.0)
        self.assertEqual(r["action"], "ignore")
        r = m.feed("聞いて", now=103.0)
        self.assertEqual(r["action"], "resume")


class TestMemoryAndSelfStore(unittest.TestCase):
    def test_memory_search_ngram(self):
        with tempfile.TemporaryDirectory() as d:
            db = j.MemoryDB(os.path.join(d, "m.db"))
            db.add("p1", "user", "私の好きな食べ物はプリンだよ")
            db.add("p1", "assistant", "プリン、覚えたよ")
            self.assertEqual(db.count("p1"), 2)
            hits = db.search("p1", "プリン")
            self.assertEqual(len(hits), 2)
            self.assertEqual(db.search("p2", "プリン"), [])

    def test_self_profile_save_load_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "self.json")
            prof = j.parse_self_profile("口癖は「まあいいか」です。プリンが好きです。")
            j.save_self_profile(prof, path=path)
            loaded = j.load_self_profile(path)
            self.assertEqual(loaded, prof)

    def test_assemble_context_separation(self):
        with tempfile.TemporaryDirectory() as d:
            db = j.MemoryDB(os.path.join(d, "m.db"))
            persona = {"id": "p1", "display_name": "執事", "input_word": "執事",
                       "memo": "", "profile": {"speech": "丁寧に話す"}, "web_summary": "", "extra_prompt": ""}
            prof = j.empty_self_profile()
            prof["basic"] = "鳥本人マークQ"
            cfg = dict(j.DEFAULT_CONFIG)
            system, turns = j.assemble_context(db, persona, prof, "やあ", cfg)
            self.assertIn("鳥本人マークQ", system)
            self.assertIn("自分コピー", system)
            self.assertEqual(turns[-2][0], "user")  # system再注入の直前が user


if __name__ == "__main__":
    unittest.main()
