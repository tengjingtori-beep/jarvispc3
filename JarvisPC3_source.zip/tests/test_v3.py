# -*- coding: utf-8 -*-
import json
import os
import sys
import tempfile
import unittest

_here = os.path.dirname(__file__)
sys.path.insert(0, os.path.abspath(os.path.join(_here, "..", "app")))
import jarvis3 as j


class TestSelfProfile(unittest.TestCase):
    def test_never_drops_sentences(self):
        text = ("名前は鳥です。好きな食べ物はプリンです。"
                "全然関係ない不思議な文がここにあります。"
                "いつも朝は早く起きます。")
        prof = j.parse_self_profile(text)
        joined = "\n".join(prof.values())
        for sent in ("名前は鳥です", "好きな食べ物はプリンです",
                     "全然関係ない不思議な文がここにあります", "いつも朝は早く起きます"):
            self.assertIn(sent, joined)

    def test_heading_split(self):
        text = "# 話し方\n一人称は僕です。\n# 好き嫌い\nプリンが好きです。\n"
        prof = j.parse_self_profile(text)
        self.assertIn("一人称は僕です", prof["speech"])
        self.assertIn("プリンが好きです", prof["likes_dislikes"])

    def test_keyword_split(self):
        prof = j.parse_self_profile("口癖は「まあいいか」です。毎日ジョギングをします。")
        self.assertIn("口癖", prof["speech"])
        # 「毎日」→ 習慣キーワード
        prof2 = j.parse_self_profile("毎日ジョギングをします。")
        self.assertIn("ジョギング", prof2["habits"])

    def test_json_input(self):
        prof = j.parse_self_profile(json.dumps({"basic": "鳥です", "謎キー": "捨てない値"}, ensure_ascii=False))
        self.assertIn("鳥です", prof["basic"])
        self.assertIn("捨てない値", prof["memories"])

    def test_all_eight_fields_exist(self):
        prof = j.parse_self_profile("テストです。")
        self.assertEqual(set(prof.keys()), {k for k, _ in j.SELF_FIELDS})


class TestPersonaVsSelfSeparation(unittest.TestCase):
    def _persona(self):
        return {"id": "p1", "display_name": "ツンデレ執事", "input_word": "ツンデレ執事",
                "memo": "", "profile": {"speech": "語尾は〜だぞ", "traits": "ツンデレ"},
                "web_summary": "", "extra_prompt": ""}

    def test_both_sections_present_and_separate(self):
        prof = j.empty_self_profile()
        prof["basic"] = "鳥本人データXYZ"
        prompt = j.build_full_system_prompt(self._persona(), prof, copy_mode=False, cfg={})
        self.assertIn("ツンデレ執事", prompt)
        self.assertIn("鳥本人データXYZ", prompt)
        # 性格セクションには自分コピーの印が無く、自分コピー側にだけ印がある
        persona_sec = j.build_persona_section(self._persona())
        self.assertNotIn("自分コピー", persona_sec)
        self_sec = j.build_self_section(prof, copy_mode=False)
        self.assertIn("自分コピー", self_sec)
        self.assertNotIn("ツンデレ執事", self_sec)

    def test_copy_mode_strengthens(self):
        prof = j.empty_self_profile()
        prof["speech"] = "一人称は僕"
        off = j.build_self_section(prof, copy_mode=False)
        on = j.build_self_section(prof, copy_mode=True)
        self.assertNotIn("自分コピーモードON", off)
        self.assertIn("自分コピーモードON", on)
        self.assertIn("鳥の分身", on)
        self.assertGreater(len(on), len(off))

    def test_empty_self_gives_no_section(self):
        self.assertEqual(j.build_self_section(j.empty_self_profile()), "")


class TestMaker(unittest.TestCase):
    def test_parse_plan(self):
        text = ("要素:\n- 計算ができる\n- ボタンがある\n"
                "ファイル: calc.py\n```python\nprint(1+1)\n```\n")
        plan = j.parse_maker_plan(text)
        self.assertEqual(plan["elements"], ["計算ができる", "ボタンがある"])
        self.assertEqual(len(plan["files"]), 1)
        self.assertEqual(plan["files"][0]["name"], "calc.py")
        self.assertIn("print(1+1)", plan["files"][0]["body"])

    def test_verify_py_ok_and_ng(self):
        with tempfile.TemporaryDirectory() as d:
            good = os.path.join(d, "a.py")
            with open(good, "w", encoding="utf-8") as f:
                f.write("x = 1\nprint(x)\n")
            ok, _msg = j.verify_created_file(good)
            self.assertTrue(ok)
            bad = os.path.join(d, "b.py")
            with open(bad, "w", encoding="utf-8") as f:
                f.write("def broken(:\n")
            ok, _msg = j.verify_created_file(bad)
            self.assertFalse(ok)

    def test_verify_json_ok_and_ng(self):
        with tempfile.TemporaryDirectory() as d:
            good = os.path.join(d, "a.json")
            with open(good, "w", encoding="utf-8") as f:
                f.write('{"a": 1}')
            self.assertTrue(j.verify_created_file(good)[0])
            bad = os.path.join(d, "b.json")
            with open(bad, "w", encoding="utf-8") as f:
                f.write("{壊れた")
            self.assertFalse(j.verify_created_file(bad)[0])

    def test_verify_html_ok_and_ng(self):
        with tempfile.TemporaryDirectory() as d:
            good = os.path.join(d, "a.html")
            with open(good, "w", encoding="utf-8") as f:
                f.write("<html><body><p>やあ</p><br></body></html>")
            self.assertTrue(j.verify_created_file(good)[0])
            bad = os.path.join(d, "b.html")
            with open(bad, "w", encoding="utf-8") as f:
                f.write("<html><body><p>閉じてない")
            self.assertFalse(j.verify_created_file(bad)[0])
            empty = os.path.join(d, "c.txt")
            with open(empty, "w", encoding="utf-8") as f:
                f.write("   ")
            self.assertFalse(j.verify_created_file(empty)[0])

    def test_maker_loop_retries_and_succeeds(self):
        calls = {"n": 0}

        def gen(system, prompt):
            calls["n"] += 1
            if "エラー" in prompt:  # 修正依頼には正しいコードを返す
                return "ファイル: a.py\n```\nprint('ok')\n```\n"
            return ("要素:\n- 挨拶する\nファイル: a.py\n```\ndef broken(:\n```\n")

        with tempfile.TemporaryDirectory() as d:
            report, results = j.maker_loop(None, "sys", "挨拶プログラム", d,
                                           cfg={}, generate_fn=gen)
            self.assertTrue(results[0]["ok"])
            self.assertIn("挨拶する", report)
            self.assertGreaterEqual(calls["n"], 2)

    def test_maker_max_retries_constant(self):
        self.assertEqual(j.MAKER_MAX_RETRIES, 3)


class TestPureLogicV2(unittest.TestCase):
    def test_strip_think(self):
        self.assertEqual(j.strip_think("<think>考え中</think>答え"), "答え")
        self.assertEqual(j.strip_think("<think>閉じてない"), "")
        self.assertEqual(j.strip_think("普通の文"), "普通の文")

    def test_sanitize_for_speech(self):
        out = j.sanitize_for_speech("クリック: 50 50\nこんにちは。元気ですか？")
        self.assertNotIn("クリック", out)
        self.assertIn("こんにちは", out)
        self.assertEqual(j.sanitize_for_speech("```code```"), "")
        out2 = j.sanitize_for_speech("詳しくは https://example.com を見てね。")
        self.assertNotIn("http", out2)

    def test_parse_action(self):
        a = j.parse_action("クリック: 10 20")
        self.assertEqual(a["type"], "click")
        self.assertEqual((a["x"], a["y"]), (10.0, 20.0))
        a = j.parse_action("キー: ctrl+c")
        self.assertEqual(a["type"], "key")
        self.assertEqual(a["spec"], "ctrl+c")
        a = j.parse_action("ただの返事です")
        self.assertEqual(a["type"], "text")
        a = j.parse_action("ファイル作成: memo.txt\n中身です")
        self.assertEqual(a["type"], "create_file")
        self.assertEqual(a["name"], "memo.txt")

    def test_guards(self):
        self.assertTrue(j.needs_shopping_confirm("これを購入して"))
        self.assertTrue(j.needs_shopping_confirm("please buy it"))
        self.assertFalse(j.needs_shopping_confirm("メモを作って"))
        self.assertTrue(j.needs_destructive_confirm("shutdown /s"))
        self.assertTrue(j.needs_destructive_confirm("Remove-Item -Recurse C:\\x"))
        self.assertFalse(j.needs_destructive_confirm("ファイルを開いて"))

    def test_build_sarashina_prompt(self):
        p = j.build_sarashina_prompt("SYS", [("user", "やあ"), ("assistant", "やあ！")])
        self.assertTrue(p.startswith("<|system|>SYS</s>"))
        self.assertIn("<|user|>やあ</s>", p)
        self.assertTrue(p.endswith("<|assistant|>"))

    def test_sanitize_relpath_and_safe_join(self):
        self.assertEqual(j.sanitize_relpath("../evil.txt"), "evil.txt")
        self.assertEqual(j.sanitize_relpath("a/b/c.txt"), "a/b/c.txt")
        with tempfile.TemporaryDirectory() as d:
            inside = j.safe_join(d, "sub/file.txt")
            self.assertTrue(inside.startswith(os.path.abspath(d)))
            self.assertIsNotNone(j.safe_join(d, "..\\..\\x.txt"))  # 安全化されて中に入る

    def test_parse_profile_json_rescue(self):
        raw = '前置き```json\n{"identity": "x", "traits": "y"}\n```後置き'
        prof = j.parse_profile_json(raw)
        self.assertEqual(prof["identity"], "x")
        self.assertIsNone(j.parse_profile_json("jsonじゃない"))
        broken = '{"identity": "救済テスト", "speech": "口調" 壊れた'
        prof2 = j.parse_profile_json(broken)
        self.assertIsNotNone(prof2)
        self.assertEqual(prof2["identity"], "救済テスト")

    def test_listen_state_machine(self):
        m = j.ListenStateMachine()
        r = m.feed("ジャービス、天気は？", now=100.0)
        self.assertEqual(r["action"], "message")
        r = m.feed("静かにして", now=101.0)
        self.assertEqual(r["action"], "quiet")
        r = m.feed("何か話して", now=102.0)
        self.assertEqual(r["action"], "ignore")
        r = m.feed("聞いて", now=103.0)
        self.assertEqual(r["action"], "resume")


class TestMemoryAndSelfStore(unittest.TestCase):
    def test_memory_search_ngram(self):
        with tempfile.TemporaryDirectory() as d:
            db = j.MemoryDB(os.path.join(d, "m.db"))
            db.add("p1", "user", "私の好きな食べ物はプリンだよ")
            db.add("p1", "assistant", "プリン、覚えたよ")
            self.assertEqual(db.count("p1"), 2)
            hits = db.search("p1", "プリン")
            self.assertEqual(len(hits), 2)
            self.assertEqual(db.search("p2", "プリン"), [])

    def test_self_profile_save_load_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "self.json")
            prof = j.parse_self_profile("口癖は「まあいいか」です。プリンが好きです。")
            j.save_self_profile(prof, path=path)
            loaded = j.load_self_profile(path)
            self.assertEqual(loaded, prof)

    def test_assemble_context_separation(self):
        with tempfile.TemporaryDirectory() as d:
            db = j.MemoryDB(os.path.join(d, "m.db"))
            persona = {"id": "p1", "display_name": "執事", "input_word": "執事",
                       "memo": "", "profile": {"speech": "丁寧に話す"}, "web_summary": "", "extra_prompt": ""}
            prof = j.empty_self_profile()
            prof["basic"] = "鳥本人マークQ"
            cfg = dict(j.DEFAULT_CONFIG)
            system, turns = j.assemble_context(db, persona, prof, "やあ", cfg)
            self.assertIn("鳥本人マークQ", system)
            self.assertIn("自分コピー", system)
            self.assertEqual(turns[-2][0], "user")  # system再注入の直前が user


class TestSelfProfileFormatsV31(unittest.TestCase):
    """v3.1: どんな書き方でも読み込めることのテスト。"""
    def _joined(self, prof):
        return "\n".join(prof.values())

    def test_heading_symbol_and_brackets(self):
        text = "■ 好き嫌い\nズンダモチが好きです。\n【習慣】\n毎朝ストレッチをします。"
        prof = j.parse_self_profile(text)
        self.assertIn("ズンダモチ", prof["likes_dislikes"])
        self.assertIn("ストレッチ", prof["habits"])

    def test_kv_variants_and_expanded_aliases(self):
        text = "名前＝トリ\n年齢: 15歳\n住所→東京の西側\n好きな食べ物：カレーライス"
        prof = j.parse_self_profile(text)
        joined = self._joined(prof)
        for w in ("トリ", "15歳", "東京の西側", "カレーライス"):
            self.assertIn(w, joined)
        self.assertIn("カレーライス", prof["likes_dislikes"])

    def test_unknown_key_kept_with_key_name(self):
        prof = j.parse_self_profile("推し活メモ：ヒミツの合言葉はホシゾラ")
        joined = self._joined(prof)
        self.assertIn("ホシゾラ", joined)
        self.assertIn("推し活メモ", joined)

    def test_bullets(self):
        text = ("・特技はモノマネです\n①毎晩日記を書きます\n"
                "1. 夢は宇宙旅行です\n- 苦手なのは早起きです")
        prof = j.parse_self_profile(text)
        joined = self._joined(prof)
        for w in ("モノマネ", "日記を書きます", "宇宙旅行", "早起き"):
            self.assertIn(w, joined)

    def test_qa_format_keeps_question_and_answer(self):
        text = ("Q: 好きな飲み物は？\nA: ココアです。\n"
                "質問：苦手なことは？\n答え：人前で歌うことです。")
        prof = j.parse_self_profile(text)
        joined = self._joined(prof)
        for w in ("ココア", "人前で歌う", "好きな飲み物は", "苦手なことは"):
            self.assertIn(w, joined)

    def test_chat_log_format(self):
        text = ("鳥：僕はプラモデルを作るのが好きです。\n"
                "友達：今度一緒に作ろうよ、楽しみにしてる。")
        prof = j.parse_self_profile(text)
        joined = self._joined(prof)
        self.assertIn("プラモデル", joined)
        self.assertIn("今度一緒に作ろうよ", prof["memories"])
        self.assertIn("会話相手", prof["memories"])

    def test_markdown_table(self):
        text = ("| 項目 | 内容 |\n|---|---|\n"
                "| 趣味 | プラモデル作り |\n| 苦手な食べ物 | パクチー |")
        prof = j.parse_self_profile(text)
        self.assertIn("プラモデル作り", prof["likes_dislikes"])
        self.assertIn("パクチー", prof["likes_dislikes"])

    def test_csv_and_tsv(self):
        prof = j.parse_self_profile("項目,内容\n名前,トリ\n趣味,プラモデル作り")
        joined = self._joined(prof)
        self.assertIn("トリ", joined)
        self.assertIn("プラモデル作り", joined)
        prof2 = j.parse_self_profile("名前\tトリ\n夢\t宇宙旅行")
        joined2 = self._joined(prof2)
        self.assertIn("トリ", joined2)
        self.assertIn("宇宙旅行", joined2)

    def test_diary_format_keeps_date(self):
        text = ("2026年11月20日\n今日は新しい自転車をもらった。\n"
                "2026/11/21 朝から公園でサッカーをした。")
        prof = j.parse_self_profile(text)
        self.assertIn("新しい自転車", prof["memories"])
        self.assertIn("2026年11月20日", prof["memories"])
        self.assertIn("サッカー", prof["memories"])
        self.assertIn("2026/11/21", prof["memories"])

    def test_long_text_without_newlines(self):
        text = ("僕は山の近くの家に住んでいます。毎朝犬と散歩をします。"
                "好きなアニメはロボットものです。将来は自分の店を持ちたいと思っています。")
        prof = j.parse_self_profile(text)
        joined = self._joined(prof)
        for w in ("山の近く", "犬と散歩", "ロボットもの", "自分の店"):
            self.assertIn(w, joined)

    def test_json_list_and_nested_dict(self):
        raw = json.dumps({"好きなもの": ["プリン", "カレー", "プラモデル"],
                          "詳細": {"出身": "山の町", "メモ": "ヒミツワード"}},
                         ensure_ascii=False)
        prof = j.parse_self_profile(raw)
        joined = self._joined(prof)
        for w in ("プリン", "カレー", "プラモデル", "ヒミツワード", "山の町"):
            self.assertIn(w, joined)

    def test_lossless_mixed_text(self):
        text = ("# 基本\n名前はミドリです。\n"
                "・好きな食べ物はオムライスです\n"
                "Q: 休みの日は何をする？\nA: 川で釣りをします。\n"
                "2025年4月3日 初めて自転車に乗れた日です。\n"
                "謎の言葉：合言葉はツキノワグマ。\n"
                "これはどこにも分類できない不思議な一文です。")
        prof = j.parse_self_profile(text)
        joined = self._joined(prof)
        for w in ("ミドリ", "オムライス", "釣り", "自転車", "ツキノワグマ",
                  "分類できない不思議な一文"):
            self.assertIn(w, joined)

    def test_normal_sentences_not_mistaken_for_qa(self):
        prof = j.parse_self_profile("問題は明日の天気です。答えはまだ分かりません。")
        joined = self._joined(prof)
        self.assertIn("問題は明日の天気です", joined)
        self.assertIn("答えはまだ分かりません", joined)


class TestDecodeAndChunksV31(unittest.TestCase):
    """v3.1: 文字コード自動判定と原文チャンク全文保存。"""
    def test_decode_shift_jis(self):
        data = "名前は鳥です。プリンが大好きです。".encode("cp932")
        self.assertEqual(j.decode_text_bytes(data), "名前は鳥です。プリンが大好きです。")

    def test_decode_utf8_and_utf16(self):
        self.assertEqual(j.decode_text_bytes("趣味はプラモデルです。".encode("utf-8")),
                         "趣味はプラモデルです。")
        self.assertEqual(j.decode_text_bytes("趣味はプラモデルです。".encode("utf-16")),
                         "趣味はプラモデルです。")
        bom = b"\xef\xbb\xbf" + "名前は鳥です。".encode("utf-8")
        self.assertEqual(j.decode_text_bytes(bom), "名前は鳥です。")

    def test_chunk_text_sentence_boundaries(self):
        text = "これはテスト文です。" * 60
        chunks = j.chunk_text(text)
        self.assertGreater(len(chunks), 1)
        for c in chunks:
            self.assertLessEqual(len(c), 400)
        self.assertEqual("".join(chunks), text)

    def test_append_and_load_chunks_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "chunks.jsonl")
            n = j.append_self_chunks("a.txt", "名前は鳥です。プリンが好きです。", path=path)
            self.assertGreaterEqual(n, 1)
            j.append_self_chunks("b.txt", "趣味はプラモデルです。", path=path)
            loaded = j.load_self_chunks(path)
            texts = "".join(c["text"] for c in loaded)
            self.assertIn("プリンが好きです", texts)
            self.assertIn("プラモデルです", texts)
            self.assertEqual({c["source"] for c in loaded}, {"a.txt", "b.txt"})

    def test_import_file_shift_jis_with_chunks(self):
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "profile.txt")
            with open(src, "wb") as f:
                f.write("名前は鳥です。ズンダモチが好きです。".encode("cp932"))
            chunks_path = os.path.join(d, "chunks.jsonl")
            prof, raw = j.import_self_profile_file(src, chunks_path=chunks_path)
            self.assertIn("鳥です", raw)
            joined = "\n".join(prof.values())
            self.assertIn("ズンダモチ", joined)
            loaded = j.load_self_chunks(chunks_path)
            self.assertIn("ズンダモチ", "".join(c["text"] for c in loaded))


class TestSelfContextV31(unittest.TestCase):
    """v3.1: build_self_context の長さ制限と query 優先。"""
    def _long_profile(self):
        prof = j.empty_self_profile()
        prof["basic"] = "名前は鳥です。" * 30
        prof["likes_dislikes"] = "好きな食べ物はズンダモチです。" + "関係ない文です。" * 40
        return prof

    def test_context_within_max_chars(self):
        ctx = j.build_self_context(self._long_profile(), max_chars=200)
        self.assertLessEqual(len(ctx), 200)
        self.assertTrue(ctx)

    def test_context_query_priority(self):
        ctx = j.build_self_context(self._long_profile(),
                                    query="ズンダモチが食べたい", max_chars=300)
        self.assertLessEqual(len(ctx), 300)
        self.assertIn("ズンダモチ", ctx)

    def test_context_empty_profile(self):
        self.assertEqual(j.build_self_context(j.empty_self_profile()), "")
        sec = j.build_self_section(self._long_profile(), query="ズンダモチ")
        self.assertIn("ズンダモチ", sec)


class TestModelDetectV32(unittest.TestCase):
    """v3.2: モデル自動検出の探索拡張（Downloads等も探す）。"""
    def _mk(self, d, name, size):
        p = os.path.join(d, name)
        with open(p, "wb") as f:
            f.write(b"x" * size)
        return p

    def test_sarashina_preferred_over_bigger(self):
        with tempfile.TemporaryDirectory() as d:
            self._mk(d, "other-big.gguf", 5000)
            small = self._mk(d, "Sarashina2.2-3B-Q4.gguf", 100)
            cands = j.search_model_candidates([d])
            self.assertEqual(cands[0], small)

    def test_largest_when_no_sarashina(self):
        with tempfile.TemporaryDirectory() as d:
            self._mk(d, "a.gguf", 100)
            big = self._mk(d, "b.gguf", 900)
            self._mk(d, "not-a-model.txt", 5000)
            cands = j.search_model_candidates([d])
            self.assertEqual(cands[0], big)
            self.assertEqual(len(cands), 2)

    def test_missing_dirs_ignored_and_mmproj_skipped(self):
        with tempfile.TemporaryDirectory() as d:
            self._mk(d, "mmproj-model.gguf", 5000)
            real = self._mk(d, "model.gguf", 10)
            cands = j.search_model_candidates([os.path.join(d, "nope"), "", d])
            self.assertEqual(cands, [real])

    def test_detect_model_cfg_first_then_search(self):
        with tempfile.TemporaryDirectory() as d:
            chosen = self._mk(d, "chosen.gguf", 10)
            self.assertEqual(j.detect_model({"model_path": chosen}), chosen)
            # cfg が実在しない場合は自動検出に落ちる（落ちた先は環境依存なので型だけ確認）
            self.assertIsInstance(j.detect_model({"model_path": os.path.join(d, "ghost.gguf")}), str)


class TestApplyModelChoiceV32(unittest.TestCase):
    """v3.2: 選んだ瞬間に cfg 反映＋保存されること。"""
    def test_choice_updates_cfg_and_saves(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "Sarashina2.2-3B.gguf")
            with open(p, "wb") as f:
                f.write(b"x" * 2048)
            cfg = {"model_path": ""}
            saved = []
            ok, msg = j.apply_model_choice(cfg, p, save_fn=lambda c: saved.append(dict(c)))
            self.assertTrue(ok)
            self.assertEqual(cfg["model_path"], p)
            self.assertEqual(len(saved), 1)
            self.assertEqual(saved[0]["model_path"], p)
            self.assertIn("Sarashina2.2-3B.gguf", msg)
            self.assertIn("MB", msg)

    def test_missing_file_rejected(self):
        cfg = {"model_path": "keep.gguf"}
        saved = []
        ok, msg = j.apply_model_choice(cfg, "/no/such/file.gguf",
                                       save_fn=lambda c: saved.append(c))
        self.assertFalse(ok)
        self.assertEqual(cfg["model_path"], "keep.gguf")
        self.assertEqual(saved, [])

    def test_non_gguf_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "model.bin")
            with open(p, "wb") as f:
                f.write(b"x")
            cfg = {"model_path": ""}
            ok, _msg = j.apply_model_choice(cfg, p)
            self.assertFalse(ok)
            self.assertEqual(cfg["model_path"], "")

    def test_mmproj_key(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "mmproj.gguf")
            with open(p, "wb") as f:
                f.write(b"x" * 10)
            cfg = {"model_path": "", "mmproj_path": ""}
            ok, _msg = j.apply_model_choice(cfg, p, key="mmproj_path")
            self.assertTrue(ok)
            self.assertEqual(cfg["mmproj_path"], p)
            self.assertEqual(cfg["model_path"], "")

    def test_empty_path_rejected(self):
        cfg = {"model_path": ""}
        ok, _msg = j.apply_model_choice(cfg, "")
        self.assertFalse(ok)


if __name__ == "__main__":
    unittest.main()
